#This add-on script clusters CDR-H3 nucleotide junctions of <20nt to exactly 1 allowed nt mismatch
#Perform this script on the "EXPTNAME"_unique_pairs_over1read.txt data after it has been appended for SHM info using the SHM annotation scripts
#filelist.txt contains the file on column 1 and the exptname prefix on column 2

while read line
do
	date
	FILENAME=$(echo $line | awk '{print $1}')
	EXPTNAME=$(echo $line | awk '{print $2}')
	echo $FILENAME
	echo $EXPTNAME
	awk 'BEGIN {temp="AAAAAAAAAAAAAAAAAAAAAAAA"}; {pad=(26-length($2)); if(length($2)<26) print ">"$2 "_pad_" pad "\n" $2 substr(temp,1,pad)}' $FILENAME > "$EXPTNAME"temp.fasta
	usearch -cluster "$EXPTNAME"temp.fasta -w 2 --maxrejects 0 -usersort --queryalnfract 1.0 --targetalnfract 1.0 --iddef 2 --nofastalign -id 0.96 -minlen 11 -uc "$EXPTNAME"results.uc -seedsout "$EXPTNAME"seeds.uc
	awk '{if(length($2)>=26)print}' $FILENAME > "$EXPTNAME"longer.temp
	awk '{if(length($2)<26)print}' $FILENAME| sort -k 2,2 > "$EXPTNAME"shorter.temp
	grep ^C "$EXPTNAME"results.uc | awk '{print $9}' | sed 's/_pad_/\t/g' | awk '{print $1}' | sort > "$EXPTNAME"temp2.txt
	join -t $'\t' -j1 2 -j2 1 -o 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 1.10 1.11 1.12 1.13 1.14 1.15 1.16 1.17 1.18 1.19 1.20 1.21 1.22 1.23 1.24 1.25 "$EXPTNAME"shorter.temp "$EXPTNAME"temp2.txt > "$EXPTNAME"temp3.txt
	cat "$EXPTNAME"temp3.txt "$EXPTNAME"longer.temp | sort -n -r | sed 's/\r/\n/g' > "$EXPTNAME"final.txt
	date
done < filelist.txt



