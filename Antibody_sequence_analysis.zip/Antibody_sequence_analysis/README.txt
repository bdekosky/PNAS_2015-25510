This suite of scripts performs the antibody sequence analysis pipeline.

****************

Order of operations:

1)  Quality filtering of raw antibody paired heavy-light sequence data to a Q-score of 20 over 50% of the read (fastx_toolkit, http://hannonlab.cshl.edu/fastx_toolkit/)

2)  Fastq to fasta file conversion

3a)  i. IMGT analysis of fasta files (need the 3_nucleotide IMGT output files)
3a)  ii. VH:VL clustering of IMGT output data using the script included here
3b)  IgBLAST analysis of antibody sequence data using the scripts included here and for annotation of antibody isotype.

4)  Consolidation of IMGT and IgBLAST results.  If the same VH:VL sequence was identified in both analyses, IMGT gene assignments were given priority.  Isotype identification was obtained from the IgBLAST custom scripts applied in Step 3b.

5)  Annotation of SHM using the attached scripts.

6)  Use shortclust.sh to additionally cluster any sequences with CDR-H3 length < 20 nt to a minimum of 1 nucleotide allowed mismatch

At this stage the antibody sequence database files complete and can be used for calculation and analysis of gene usage and sequence-based parameters (e.g. CDR3 hydrophobicity, length, etc.) using appropriate statistical and graphical software.  The majority of statistical and graphical analyses were performed using R and Microsoft Excel, as detailed in the Online Methods Section.

