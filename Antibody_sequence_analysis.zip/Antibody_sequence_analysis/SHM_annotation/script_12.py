#Purpose: script to map pairs back from the concatenated file back to the actual VHVL paired file
#Usage: python script_12.py concatenated_paired_file_for_502_or_503 VHVL_paired_file

import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter
from decimal import Decimal




concatenated_dict=defaultdict(list)

inputfile=open(sys.argv[1])

for line in inputfile:
	strip_line=line.rstrip()
	split_line=strip_line.split("\t")
#	print split_line
	stuff=split_line[2]+"\t"+split_line[3]
	CDRH3=split_line[0]
	CDRL3=split_line[1]
	pair=CDRH3+"?"+CDRL3
#	print pair
	if str(stuff).find("No FR3 Identity")!=-1:
		stuff=stuff.replace("No FR3 Identity", "None")
	concatenated_dict[pair].append(stuff)
	
inputfile.close()

for key in concatenated_dict:
#	print key
	if len(concatenated_dict[key])>0:
		concatenated_dict[key]="\t".join(concatenated_dict[key])
		concatenated_dict[key]=concatenated_dict[key].replace(" ", "\t")
#		print concatenated_dict[key]

#print concatenated_dict

pairs_of_interest_dict={}

pairs_output_dict=defaultdict(list)

def pairs_of_interest(pairs_output_dict, pairs_of_interest_dict):

        inputfile=open(sys.argv[2])
	k=0
        for line in inputfile:
		k+=1
                strip_line=line.rstrip()
		#pairs_output_dict[k]=strip_line
                split_line=strip_line.split("\t")
                reads=split_line[0]
                CDRH3=split_line[1]#[:-3]
                #CDRH3=CDRH3[3:]
                CDRL3=split_line[2]#[:-3]
                #CDRL3=CDRL3[3:]
                pair=CDRH3+"?"+CDRL3
		#if pair in pairs_of_interest_dict.keys():
		#	print "already exists"
		#	print pair
                pairs_of_interest_dict[pair]=reads
	#	pairs_output_dict[pair].append(reads)
#		print pair
		pairs_output_dict[pair].append(strip_line)

#	print len(pairs_of_interest_dict)
	print k
#	print len(pairs_output_dict)
#	print pairs_output_dict
pairs_of_interest(pairs_output_dict, pairs_of_interest_dict)


#final_dict=defaultdict(list)


outputfile=open("{0}_mapped.txt".format(sys.argv[1]), "w")

temp_dict={}

def temp(pairs_of_interest_dict, temp_dict):

	for key in pairs_of_interest_dict:
		value=pairs_of_interest_dict[key]
#		print value
		#split_line=value.split("\t")
		reads=int(value)
		temp_dict[key]=reads

temp(pairs_of_interest_dict, temp_dict)

temp_sorted=sorted(temp_dict.iteritems(), key=operator.itemgetter(1), reverse=True)
#reversed=temp_sorted.reverse()

#k=0
#f#or item in temp_sorted:
#	if k<20:
#		print item

#
#print temp_sorted

for listed_item in temp_sorted:
	key=listed_item[0]
#	print key
	if concatenated_dict[key]!=[]:
		shortened=pairs_output_dict[key]
		for item in shortened:
			outputfile.write("{0}".format(item))
#			print item
		#thing=concatenated_dict[key][0]
#		print concatenated_dict[key]
		
		thing=concatenated_dict[key]
#		print thing
		thing=thing.replace(" ", "\t")
#			print key
		#print thing
		split_thing=thing.split("\t")
#		print split_thing
			#double_split=split_thing.split(" ")
#			print double_split
		take_this_1=split_thing[1]
		take_this_2=split_thing[2]
		#double_split=take_this_2.split(" ")[1]
		take_this_3=split_thing[4]
#		double_split=take_this_3.split(" ")[1]
		take_this_4=split_thing[5]
		outputfile.write("\t{0}".format(take_this_1))
		outputfile.write("\t{0}".format(take_this_2))
		outputfile.write("\t{0}".format(take_this_3))
		outputfile.write("\t{0}".format(take_this_4))
#		print thing
#		try:
#			take_this_5=split_thing[7]
#			print take_this_5
#			outputfile.write("\t{0}".format(take_this_5))
#		except:
#			outputfile.write("\tNone")
#		try:
#                       take_this_6=split_thing[8]
#			print take_this_6	
#                        outputfile.write("\t{0}".format(take_this_6))
#                except:
 #                       outputfile.write("\tNone")
#		try:
 #                       take_this_7=split_thing[10]
#			print take_this_7
 #                       outputfile.write("\t{0}".format(take_this_7))
  #              except:
   #                     outputfile.write("\tNone")
#		try:
 #                       take_this_8=split_thing[11]
#	                print take_this_8
 #                       outputfile.write("\t{0}".format(take_this_8))
  #              except:
   #                     outputfile.write("\tNone")
#	
		outputfile.write("\n")
	else:
		shortened=pairs_output_dict[key]
		for item1 in shortened:
			outputfile.write("{0}".format(item1))
		outputfile.write("\tNone\tNone\tNone\tNone")
#		for thing in concatenated_dict[pair]:
#			outputfile.write("\t{0}".format(thing))
		outputfile.write("\n")

outputfile.close()
	
