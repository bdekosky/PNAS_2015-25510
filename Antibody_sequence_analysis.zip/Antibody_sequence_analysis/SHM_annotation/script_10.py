#Purpose: script to merge the output of script_9.py and concatenate split experiments such as 483/484 information (FR3 identity and cluster size into one paired file)
#Usage: python script_10.py first_paired_file_of_split_experiment second_paired_file_of_split_experiment prefix_for_output

#the two files must be the exact same number of lines


import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter
from decimal import Decimal

inputfile=open(sys.argv[1])

master_paired_file=defaultdict(list)

k=0
for line in inputfile:
	strip_line=line.rstrip()
	k+=1
	master_paired_file[k].append(strip_line)

inputfile.close()

inputfile=open(sys.argv[2])

k=0
for line in inputfile:
	k+=1
	strip_line=line.rstrip()
	split_line=strip_line.split("\t")
	len_line=len(split_line)
	VH_identity="\t"+split_line[len_line-4]
	VL_identity="\t"+split_line[len_line-3]
	VH_cluster_size="\t"+split_line[len_line-2]
	VL_cluster_size="\t"+split_line[len_line-1]

	master_paired_file[k].append(VH_identity)
	master_paired_file[k].append(VL_identity)
	master_paired_file[k].append(VH_cluster_size)
	master_paired_file[k].append(VL_cluster_size)

inputfile.close()

	
sorted_dict=sorted(master_paired_file)

outputfile=open("{0}_merged_paired_file.txt".format(sys.argv[3]), "w")

for item in sorted_dict:
	value=master_paired_file[item]
	for something in value:
		outputfile.write("{0}".format(something))
		
	outputfile.write("\n")
