#Purpose: script that takes one of the many 502-503 8_IMGT files and maps it back to its corresponding FR3 file and puts the mutation rate in the identifier name (cluster size is already there)
#Usage: python script_11.py FR3_consensus_sequence_file IMGT_8_mut_stat_file

import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter
from decimal import Decimal



error_file=open("{0}_errors.fasta".format(sys.argv[1]), "w")



FR3_dict=defaultdict(list)
tracking_dict=defaultdict(list)


other_FR3_dict=defaultdict(list)
other_tracking_dict=defaultdict(list)


def extract_original_FR3(FR3_dict, tracking_dict):
	
	inputfile=open(sys.argv[1])
		
	data=inputfile.readlines()
	
	inputfile.close()

	k=0
	for line in data:
		#print line
		k+=1
	j=0
	while j<(k):
		identifier=data[j]
		strip_identifier=identifier.rstrip()
		#order will be CDR3 pair name, short identifier, heavyseq, lightseq 
		split_ident=strip_identifier.split(">")[1]
		split_split_ident=split_ident.split(" ")
		CDR3_pair=split_split_ident[0]
		short_heavy_name=split_split_ident[1]
		short_heavy_name_plus_cluster_size=split_split_ident[1]+" "+split_split_ident[2]
		heavyseq=data[j+1].rstrip()

		light_identifier=data[j+2].rstrip()
		split_light_identifier=light_identifier.split(" ")
		short_light_name=split_light_identifier[1]+" "+split_light_identifier[2]

		lightseq=data[j+3].rstrip()
		short_heavy_name=short_heavy_name.replace("H", "")
		FR3_dict[short_heavy_name].append(CDR3_pair)
		FR3_dict[short_heavy_name].append(short_heavy_name_plus_cluster_size)
		FR3_dict[short_heavy_name].append(heavyseq)
		FR3_dict[short_heavy_name].append(short_light_name)
		FR3_dict[short_heavy_name].append(lightseq)

		tracking_dict[CDR3_pair].append(split_split_ident[2])
		tracking_dict[CDR3_pair].append(split_light_identifier[2])
		tracking_dict[CDR3_pair].append(short_heavy_name_plus_cluster_size)
		tracking_dict[CDR3_pair].append(heavyseq)
		tracking_dict[CDR3_pair].append(short_light_name)
		tracking_dict[CDR3_pair].append(lightseq)
		tracking_dict[CDR3_pair].append(CDR3_pair)
		
#		print FR3_dict[short_heavy_name]
		j+=4

#	print FR3_dict

extract_original_FR3(FR3_dict,tracking_dict)

mutation_dict={}


def extract_8_IMGT_data_line_by_line(mutation_dict):
	
	inputfile=open(sys.argv[2])
	
	mutations=" "
	
	k=0
	for line in inputfile:
		strip_line=line.rstrip()

		split_line=strip_line.split("\t")
		#print len(split_line)
		#if len(split_line)!=130:
		#	print split_line
		if len(split_line)>97 and line.find("Functionality")==-1:
			identifier=split_line[1]
			split_ident=identifier.split(" ")
			first_section=split_ident[0]
			#identifier=split_ident[5]+":"+split_ident[6]
			if split_line[97]!='':
				mutations=split_line[97]
				#print "made it here"
			if mutations.find("(")!=-1:
				mutations_split=mutations.split("(")
				mutations=mutations_split[0]
			#else:
			#	mutations="0"
			########################################################Calculate thte FR3 % Identity
			length_FR3=int(split_line[95])
#			print length_FR3
#			print float(length_FR3)
#			print mutations
			mutations=int(mutations)
			percent_identity=(1-(mutations/float(length_FR3)))*100			
			#if percent_identity=='':
			#	print "MISTAKE"
			#	print first_section
			mutation_dict[first_section]=percent_identity
#			print first_section
			if k%1000000==0 and k!=0:
				print k
#			print k
			k+=1

		
	inputfile.close()

extract_8_IMGT_data_line_by_line(mutation_dict)

######################################################################################################
#print mutation_dict

collapsed_mutation_dict=defaultdict(list)

def collapse_mutation_dict(mutation_dict, collapsed_mutation_dict, error_file):

	#print "got here"
	for key in mutation_dict:
#		if key=="5":
#		print key
#		print mutation_dict[key]
			#print mutation_dict["5H"]
			#print mutation_dict["5L"]
		if key.find("H")!=-1: # and len(collapsed_mutation_dict[key])<4:
			short_key=key.replace("H","")
#			print key
#			print short_key
#			print "got here"
#			print len(collapsed_mutation_dict[key])
			
			if len(collapsed_mutation_dict[short_key])==0:
				#print "got here"
				type="Heavy"
				collapsed_mutation_dict[short_key].append(type)
				collapsed_mutation_dict[short_key].append(mutation_dict[key])
				other_key=short_key+"L"
#				print other_key
				#print mutation_dict[other_key]
				try:
				#	print mutation_dict[other_key]
					collapsed_mutation_dict[short_key].append("Light")
					collapsed_mutation_dict[short_key].append(mutation_dict[other_key])
	#				print collapsed_mutation_dict
				except KeyError:
#					del collapsed_mutation_dict[short_key]
					error_file.write("{0}\n".format(key))
					error_file.write("{0}\n".format(mutation_dict[key]))
					error_file.write("{0}\n".format(other_key))
					error_file.write("{0}\n".format("None Found"))
		if key.find("L")!=-1: # and len(collapsed_mutation_dict[key])<4:
			short_key=key.replace("L","")
			if len(collapsed_mutation_dict[short_key])==0:
				type="Light"
				other_key=short_key+"H"
#				collapsed_mutation_dict[short_key].append("Light")
#				collapsed_mutation_dict[short_key].append(mutation_dict[key])
				try:
					collapsed_mutation_dict[short_key].append("Heavy")
					collapsed_mutation_dict[short_key].append(mutation_dict[other_key])
				except KeyError:
#					del collapsed_mutation_dict[short_key]
					error_file.write("{0}\n".format(other_key))
                        	        error_file.write("{0}\n".format("None Found"))
                        	        error_file.write("{0}\n".format(key))
                        	        error_file.write("{0}\n".format(mutation_dict[key]))
				collapsed_mutation_dict[short_key].append("Light")
                                collapsed_mutation_dict[short_key].append(mutation_dict[key])


#	print collapsed_mutation_dict
#	print len(collapsed_mutation_dict)
#	print len(mutation_dict)
		
collapse_mutation_dict(mutation_dict, collapsed_mutation_dict, error_file)


outputfile=open("{0}_mapped_split.txt".format(sys.argv[1]), "w")


for key in FR3_dict:
#	print key
	value=FR3_dict[key]
#	print value
	pair=value[0]
	split_pair=pair.split("?")
	CDRH3=split_pair[0]
	CDRL3=split_pair[1]
#	print collapsed_mutation_dict[key]
	try:
		heavy_name=value[1]+" "+str(collapsed_mutation_dict[key][1])
	except:
		heavy_name=value[1]+" "+"No FR3 Identity"
		
	try:
		light_name=value[3]+" "+str(collapsed_mutation_dict[key][3])
	except:
		light_name=value[3]+" "+"No FR3 Identity"
	
	outputfile.write("{0}	{1}	{2}	{3}\n".format(CDRH3, CDRL3, heavy_name, light_name))
	
	

outputfile.close()
	
