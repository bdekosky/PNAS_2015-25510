#Purpose: script for generating FR3 consensus sequences using usearch  
#Usage: python script_8.py IMGT_nt_file VHVL_paired_file


#script for generating FR3 consensus sequences using usearch 
#script has modification for taking in the paired file and only doing consensus sequences for the sequences of interest


import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter
from decimal import Decimal
from subprocess import call

##############################################Extract IMGT nucleotide file information

FR3_CDR3_dict={}
sequence_dict=defaultdict(list)

def extract_3_IMGT_data_line_by_line(FR3_CDR3_dict): #the following two functions were changed from older versions so that the modifer would contain the relevant x and y coordinates as well as the read number 
	inputfile=open(sys.argv[1])
	
	FR3=" "
	CDR3=" "
	k=0
	for line in inputfile:

		strip_line=line.rstrip()
		split_line=strip_line.split("\t")
		if len(split_line)>10 and line.find("Functionality")==-1 and split_line[2]=="productive": #must make sure there are Results and that we are not using the first line
			identifier=split_line[1]
			split_ident=identifier.split(":")
			identifier=split_ident[0]+":"+split_ident[1]+":"+split_ident[2]+":"+split_ident[3]+":"+split_ident[4]+":"+split_ident[5]+":"+split_ident[6]
#			print identifier
			if identifier.find(" ")!=-1:
				identifier=identifier.replace(" ", "_")
			if split_line[6]!='':
				type="HEAVY"
			if split_line[7]!='':
				type="LIGHT"
			if split_line[15]!='': ##############################THIS IS ACTUALLY THE JUNCTION NOT THE CDR3, THIS WAS CHANGED IN version 6 of this script 
				CDR3=split_line[15]
#				print CDR3
			if split_line[13]!='':
				FR3=split_line[13]
#				print FR3
			seq_data=str(FR3)+str(CDR3)+"?"+str(FR3)+"?"+str(CDR3)+"?"+type
			FR3_CDR3_dict[identifier]=seq_data
			if k%100000==0 and k!=0:
				print k
			k+=1		
	inputfile.close()

extract_3_IMGT_data_line_by_line(FR3_CDR3_dict)

print "Nucleotide file banked"
#####################################################################################
#for both banked dictionaries, the identifiers are the x and y coordinates with the read number attached by an underscore, so matching should be simple at this point


paired_FR3_CDR3_dict=defaultdict(list)
paired_mutation_dict=defaultdict(list)

#######################################################################################
#read in the pairs of interest that you only want to do consensus sequences for

pairs_of_interest_dict={}

def pairs_of_interest(pairs_of_interest_dict):

	inputfile=open(sys.argv[2])

	for line in inputfile:
		strip_line=line.rstrip()
		split_line=strip_line.split("\t") 
		reads=split_line[0]
		CDRH3=split_line[1]
		#CDRH3=CDRH3[3:]
		CDRL3=split_line[2]
		#CDRL3=CDRL3[3:]
		pair=CDRH3+"?"+CDRL3
		pairs_of_interest_dict[pair]=reads


pairs_of_interest(pairs_of_interest_dict)



def pair(dictionary, paired_dictionary): #this will pair everything based on identifier and filter out everything that did not get a pair
	
	track_double_heavy=0
	track_double_light=0	
	
	i=0
	j=0
	for key in dictionary:
		short_key=key.split("_")[0]
#		print short_key
		value=dictionary[key]
#		print value
#		print len(paired_dictionary[short_key])
		if len(paired_dictionary[short_key])==2:
			#print paired_dictionary[short_key]
			type=paired_dictionary[short_key][1].split("?")[3]
#			print type
			if type=='HEAVY' and value.split("?")[3]=='HEAVY':
				track_double_heavy+=1
				#print short_key
				#print value
				#print paired_dictionary[short_key]
				#print value
			if type=='LIGHT' and value.split("?")[3]=='LIGHT':
				track_double_light+=1
#				print short_key
#				print value
#				print paired_dictionary[short_key]
#				print value
#			print "got inside, but should never"
#			if key.find("_1")!=-1:

#				other_read_key=short_key+"_2"
#				try:
			value_2=dictionary[key]
#				print value_2
			paired_dictionary[short_key].append(key)
			paired_dictionary[short_key].append(value_2)

		elif paired_dictionary[short_key]==[]:
			paired_dictionary[short_key].append(key)
			paired_dictionary[short_key].append(value)
	for key in paired_dictionary:
		value=paired_dictionary[key]
		if len(value)==2:
			i+=1
		if len(value)==4:
			j+=1
	track_heavy_again=0
	for key in paired_dictionary:
		value=paired_dictionary[key]
		if len(value)==4:
			#print value[1].split("?")[3]
#			print value[3].split("?")[3]
			if value[1].split("?")[3]=="HEAVY" and value[3].split("?")[3]=="HEAVY":
#				print value
				track_heavy_again+=1


#	print track_heavy_again
	
	outputfile=open("{0}_statistics.txt".format(sys.argv[1]), "w")	
	print "Number of productive sequences"
	print len(dictionary)
	print "Number of sequences missing due to unproductivity or quality filtering"
	print i
	print "Number of good pairs"
	print j
	print "Number of Double Heavy"
	print track_double_heavy
	print "Number of Double Light"
	print track_double_light
	outputfile.write("{0}\n".format("Number of productive sequences"))
	outputfile.write("{0}\n".format(len(dictionary)))
	outputfile.write("{0}\n".format("Number of sequences missing due to unproductivity or quality filtering"))
	outputfile.write("{0}\n".format(i))
	outputfile.write("{0}\n".format("Number of Good Pairs"))
	outputfile.write("{0}\n".format(j))
	outputfile.write("{0}\n".format("Number of Double Heavy"))
	outputfile.write("{0}\n".format(track_double_heavy))
	outputfile.write("{0}\n".format("Number of Double Light"))
	outputfile.write("{0}\n".format(track_double_light))


pair(FR3_CDR3_dict, paired_FR3_CDR3_dict)
#pair(mutation_dict, paired_mutation_dict)

#print paired_FR3_CDR3_dict

############################################################################### Delete the other dictionaries
del FR3_CDR3_dict
###############################################################################

collapsed_pairs=defaultdict(list)

tracking_dict={}

def collapse_onto_paired_CDR3s(paired_FR3_CDR3_dict, collapsed_pairs):

	#I will attempt to isolate only the CDR3s of interest at this stage and hopefully that will work right
	#for key in pairs_of_interest_dict:
	#	if paired_FR3_CDR3_dict[key]!=[]:
		
	for key in paired_FR3_CDR3_dict:
#		print key
		value=paired_FR3_CDR3_dict[key]
		#print value
		if len(value)==4: #only collapse the paired information that has both heavy and light
			for item in value:
#					print item
				if item.find("HEAVY")!=-1:
					split_item=item.split("?")
					CDRH3=split_item[2]
#					print CDRH3
					HFR3=split_item[1]
#					print HFR3
					bank_HFR3=HFR3+"?"+"HEAVY"
				if isinstance(item,list)==False and item.find("LIGHT")!=-1:
					split_item=item.split("?")
					CDRL3=split_item[2]
					LFR3=split_item[1]
					bank_LFR3=LFR3+"?"+"LIGHT"
			pair=CDRH3+"?"+CDRL3
			#try tp actual collapse it here using the pairs of interest!!!!
			try:
				val=pairs_of_interest_dict[pair]
			
	#this should just tack everything onto this dictionary immediately, no matter what was there before and if not it should create a key value pair
	#no sure why i didn't think of this before 
				collapsed_pairs[pair].append(HFR3)
				collapsed_pairs[pair].append(LFR3)
				try:
					old_num=tracking_dict[pair]
					tracking_dict[pair]+=1
				except KeyError:
					tracking_dict[pair]=1			
			except KeyError:
				hi="hello"
			

#		else:
#			print "Missing pair, which would be weird"

	print "Number of collapsed pairs"
	print len(collapsed_pairs)
	print "Number of tracked pairs"
	print len(tracking_dict)
		
collapse_onto_paired_CDR3s(paired_FR3_CDR3_dict, collapsed_pairs)

#print collapsed_pairs


##########################################################################################
#begin to start manipulating this information to determine the SHM levels of both the heavy and light for one collapsed pair


#check and make sure that both the heavy and the light paired in this case are not a heavy with a heavy or a light with a light

def temporary_output_file_for_usearch(list):
	outputfile=open("temp_file.fasta", "w")
	k=0
	for item in list:
		k+=1
		outputfile.write(">{0}\n".format(k))
		outputfile.write("{0}\n".format(item))
	outputfile.close()
		

def consensus_sequence_usearch(list, type):
	outputfile=open("temp_file.fasta", "w")
	k=0
	for item in list:
		k+=1
		outputfile.write(">{0}\n".format(k))
		outputfile.write("{0}\n".format(item))
	outputfile.close()
	
#	call(["usearch", "--usersort", "temp_file.fasta", "-output", "temp_file_sorted.fasta"]) #sorts the temporary fasta file by decreasing length, does not use -sortbylength, command out of date?
	call(["usearch", "-cluster", "temp_file.fasta", "--minlen", "75", "-id", "0.9", "-consout", "temp_file_sorted_output.cons", "-uc", "temp_file_sorted_output.uc", "--usersort"]) #clusters the sequences, makes one file with consensus sequences and another file with information about the size of the clusters, for each of which there is a consensus sequence
	
	#check to see if the cluster file is empty
	inputfile=open("temp_file_sorted_output.uc","r")
	print type
	if type=="HEAVY":
		global	count_presence_heavy
		count_presence_heavy=0

		for line in inputfile:
			if line.find("#")==-1:
#				print line
				count_presence_heavy+=1
	
		if count_presence_heavy>0:
			analyze_usearch_results()
			print count_presence_heavy
			print "the above is good count presence"
		else:
			print count_presence_heavy
			print "the above is bad count heavy presence"
			call(["rm", "temp_file.fasta"])
#	        	call(["rm", "temp_file_sorted.fasta"])
        		call(["rm", "temp_file_sorted_output.uc"])
        		call(["rm", "temp_file_sorted_output.cons"])

	if type=="LIGHT":
		global count_presence_light
		count_presence_light=0
		
		for line in inputfile:
                        if line.find("#")==-1:
#                               print line
                                count_presence_light+=1

                if count_presence_light>0:
                        analyze_usearch_results()
                        print count_presence_light
                        print "the above is good count light presence"
                else:
                        print count_presence_light
                        print "the above is bad count presence"
                        call(["rm", "temp_file.fasta"])
#                       call(["rm", "temp_file_sorted.fasta"])
                        call(["rm", "temp_file_sorted_output.uc"])
                        call(["rm", "temp_file_sorted_output.cons"])



	
def analyze_usearch_results():
		
	#this function finds the largest cluster and identifies the consensus sequence associated with it
 	#if there are multiple that are the same size, it takes the first one, there is no other way around this, but that is what has been decided
	
	#it reads files in from the current directory, that were already named during the usearch function

##################################################################################First make sure the cluster file isn't empty
	inputfile=open("temp_file_sorted_output.uc", "r")
		
#	count_presence=0
#	for line in inputfile:
#		if line.find("\#")==-1:
#			count_presence+=1
	
	max_size=0
	for line in inputfile:
#		print line
		if line.find("#")==-1:
			split_line=line.split("\t")
#			print split_line
			if split_line[0]=="C" and int(split_line[2])>max_size:
				max_size=int(split_line[2])
				largest_cluster_name=str(split_line[1])
		
# 	print largest_cluster_name
	inputfile.close()
	#the largest cluster name should now be identified and stored
	
	temp_dict=defaultdict(list)
	inputfile=open("temp_file_sorted_output.cons", "r")
	for line in inputfile:
#		print line
		strip_line=line.rstrip()
		if strip_line.find(">")!=-1:
			name=str(strip_line.replace(">Cluster", ""))
		else:
			temp_dict[name].append(strip_line)
	inputfile.close()

	best_value=temp_dict[largest_cluster_name]
#	print best_value
	del temp_dict
	temp_list=[]
	for item in best_value:
		temp_list.append(item)

	#delete all the temporary files in the current working directory
	call(["rm", "temp_file.fasta"])
#	call(["rm", "temp_file_sorted.fasta"])
	call(["rm", "temp_file_sorted_output.uc"])
	call(["rm", "temp_file_sorted_output.cons"])	
	
	global read_count
	read_count=max_size
	global consensus_sequence
	consensus_sequence=("".join(temp_list)).lower()
	#return consensus_sequence
				 




new_collapsed_pairs=defaultdict(list)

def calculate_identity(collapsed_pairs, tracking_dict, new_collapsed_pairs):
	j=0
	outputfile=open("{0}_FR3_consensus_sequences.txt".format(sys.argv[1]), "w")

	errorfile=open("{0}_FR3_consensus_sequences_errors.txt".format(sys.argv[1]),"w")

	for firstkey in tracking_dict:
#		i+=1
#		print i
		value=tracking_dict[firstkey]
		#print value
		if value>=2:################################################### READS GREATER THAN 2
			j+=1
			#print i
                	temp_heavy_list=[]
#			print temp_heavy_list
#			print firstkey
			temp_light_list=[]
                	list_nums=collapsed_pairs[firstkey]
                	len_list=len(list_nums)
                	i=0
                	while i<(len_list-1):
                        	HFR3=list_nums[i]
                        	LFR3=list_nums[i+1]
                  
                        	temp_heavy_list.append(HFR3)
				temp_light_list.append(LFR3)
                        	i+=2
#			print temp_heavy_list

	#		outputfile=open("{0}_FR3_consensus_sequences.txt".format(sys.argv[1]), "w")
				
			consensus_sequence_usearch(temp_heavy_list, "HEAVY")
			#print consensus_sequence
			if count_presence_heavy>0:
				new_collapsed_pairs[firstkey].append(consensus_sequence)
				new_collapsed_pairs[firstkey].append(read_count)
#			print new_collapsed_pairs
			consensus_sequence_usearch(temp_light_list, "LIGHT")

			if count_presence_heavy and count_presence_light>0:
				new_collapsed_pairs[firstkey].append(consensus_sequence)
				new_collapsed_pairs[firstkey].append(read_count)

				outputfile.write(">{0} {1}H {2}\n".format(firstkey, j, new_collapsed_pairs[firstkey][1]))
				outputfile.write("{0}\n".format(new_collapsed_pairs[firstkey][0]))
				outputfile.write(">{0} {1}L {2}\n".format(firstkey, j, new_collapsed_pairs[firstkey][3]))
				outputfile.write("{0}\n".format(new_collapsed_pairs[firstkey][2]))
	
			if count_presence_heavy==0 or count_presence_light==0:
				#errorfile.write("Error")
				errorfile.write(">{0} {1}H {2}\n".format(firstkey, j, "Error"))
				errorfile.write("{0}\n".format(temp_heavy_list[0]))
				errorfile.write(">{0} {1}L {2}\n".format(firstkey, j, "Error"))
				errorfile.write("{0}\n".format(temp_light_list[0]))	
			
calculate_identity(collapsed_pairs, tracking_dict, new_collapsed_pairs) 

print "Number of pairs that made it through mutation analysis"
print len(new_collapsed_pairs)

#print new_collpased_pairs


def output(new_collapsed_pairs):
		
        i=0
        outputfile=open("{0}_FR3_consensus_sequences".format(sys.argv[2]),"w")

        for key in new_collapsed_pairs:
                split_key=key.split("?")
                CDRH3=split_key[0]
                CDRL3=split_key[1]

 #               if H_percent_homology>=98 and L_percent_homology>=98: #98% cutoff
  #                      i+=1
#			outputfile2.write("{0}\t{1}\t{2}\t{3}\n".format(CDRH3, H_percent_homology, CDRL3, L_percent_homology))
 #               else:
  #                      j+=1
		outputfile.write(">{0} H\n".format(CDRH3))
		outputfile.write("{0}".format(new_collapsed_pairs[key][0]))
		outputfile.write(">{0} L\n".format(CDRL3))
		outputfile.write("{0}".format(new_collpased_pairs[key][1]))
		
         #       outputfile.write("{0}\t{1}\t{2}\t{3}\n".format(CDRH3, H_percent_homology, CDRL3, L_percent_homology))

       # print "Number of pairs with average homologies greater than 98%:"
        #print i
       # print "Number of sequences with average homologies less than 98%:"
       # print j
#        outputfile.write("{0}\n".format("Number of pairs with average identities >98%"))
#       outputfile.write("{0}\n".format(i))
#        outputfile.write("{0}\n".format("Number of pairs sequences with average identities <98%"))
#        outputfile.write("{0}\n".format(j))

        outputfile.close()

#output(new_collapsed_pairs)

