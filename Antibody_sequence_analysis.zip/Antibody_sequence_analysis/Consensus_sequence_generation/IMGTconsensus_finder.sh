#!/bin/bash

#This file identifies the full consensus sequence from raw separate heavy and light chain data.
#Prior to running this script, the separate heavy and light chain sequences must be stitched together in to a single read using FLASH- (http://ccb.jhu.edu/software/FLASH/) and quality filtered using FASTX_toolkit (http://hannonlab.cshl.edu/fastx_toolkit/).  Finally, the processed fasta data should be uploaded to IMGT for annotation of antibody genes.
#Input arguments:  IMGTconsensus_finder.sh CDR3_pairs_file 3_IMGT_VH_file 3_IMGT_VL_file
#CDR3_pairs_file contains VH and VL CDR3 nucleotide sequences in columns 2 and 3, respectively
#3_IMGT_VH file contains 3_Nt VH processed full-length sequences from IMGT
#3_IMGT_VL file contains 3_Nt VL processed full-length sequences from IMGT

EXPTNAME=$1
PAIR_FILE=$2
IMGT_VH_FILE=$3
IMGT_VL_FILE=$4

rm "$EXPTNAME"paired_consensus_seqs.txt

echo "$(date +%b-%d-%H:%M:%S)   Preparing files..."

#Generate a file with all the paired sequences
awk 'BEGIN {i=1}; {print "testpairs_CDRH3_" i "_\t" $2 "\ttestpairs_CDRL3_" i "_\t" $3; i=i+1}' $PAIR_FILE > "$EXPTNAME"temppairs_CDR3seqs.txt

#Generate a sorted file with CDR3_junction "\t" VHorVL_seq "\t" read_ID
awk -F "\t" 'BEGIN {i=1}; {if($3=="productive") if(length($7)>3) if(length($16)>8) print $16 "\t" $7 "\t" $2}' $IMGT_VH_FILE | sort > "$EXPTNAME"sorted_CDR3-VH.txt
awk -F "\t" 'BEGIN {i=1}; {if($3=="productive") if(length($8)>3) if(length($16)>8) print $16 "\t" $8 "\t" $2}' $IMGT_VL_FILE | sort > "$EXPTNAME"sorted_CDR3-VL.txt

echo "$(date +%b-%d-%H:%M:%S)   Performing consensus-clustering loops for each CDR3..."

#Construct loop to read HC and LC seqs that match CDR3 junctions exactly, compile into fasta files, cluster.  Take clusters with largest size for consensus.

while read line
do 
	date
	rm "$EXPTNAME"temp_HCseqs.fasta
	rm "$EXPTNAME"temp_LCseqs.fasta

	tempH3id=$(echo $line | awk '{print $1}')
	tempH3=$(echo $line | awk '{print $2}')
	tempL3id=$(echo $line | awk '{print $3}')
	tempL3=$(echo $line | awk '{print $4}')

	#echo "H3 seq:  "$tempH3
	echo $tempH3 > "$EXPTNAME"tempVHfile
	#echo "L3 seq:  "$tempL3
	echo $tempL3 > "$EXPTNAME"tempVLfile
	
	#Isolating matching VDJ or VJ seqs from intermediate files for current H3:L3 pair
	join -t $'\t' -j 1 -o 2.1 2.2 2.3 "$EXPTNAME"tempVHfile "$EXPTNAME"sorted_CDR3-VH.txt | sort -k 3,3 -n | head -300 | awk -F "\t" 'BEGIN {i=1}; {print ">CDRH3_junction_seq_" i "_\n" $2; i=i+1}' > "$EXPTNAME"temp_HCseqs.fasta
	join -t $'\t' -j 1 -o 2.1 2.2 2.3 "$EXPTNAME"tempVLfile "$EXPTNAME"sorted_CDR3-VL.txt | sort -k 3,3 -n | head -300 | awk -F "\t" 'BEGIN {i=1}; {print ">CDRL3_junction_seq_" i "_\n" $2; i=i+1}' > "$EXPTNAME"temp_LCseqs.fasta

	#Clustering and output for HC
	usearch -cluster "$EXPTNAME"temp_HCseqs.fasta --minlen 10 -id 0.9 -consout "$EXPTNAME"temp_consensus.cons -uc "$EXPTNAME"temp_consensus.uc --usersort
	grep '^C' "$EXPTNAME"temp_consensus.uc | awk 'BEGIN {max = 0} {if ($3>max) cluster=$2; if($3>max) max=$3} END { print ">Cluster" cluster "$"}' > "$EXPTNAME"temp_cons_cluster.txt
	maxreads=$(grep '^C' "$EXPTNAME"temp_consensus.uc | awk 'BEGIN {max = 0} {if ($3>max) cluster=$2; if($3>max) max=$3} END {print max}')
	fasta_formatter -i "$EXPTNAME"temp_consensus.cons -o "$EXPTNAME"temp_consensus_oneline.cons -w 0
	echo $line | awk -v maxreads=$maxreads '{print ">" $1 $2 "_" maxreads "clusteredreads"}' >> "$EXPTNAME"paired_consensus_seqs.txt
	grep -f "$EXPTNAME"temp_cons_cluster.txt -A 1 -m 1 "$EXPTNAME"temp_consensus_oneline.cons >> "$EXPTNAME"paired_consensus_seqs.txt

	#Clustering and output for LC
	usearch -cluster "$EXPTNAME"temp_LCseqs.fasta --minlen 10 -id 0.9 -consout "$EXPTNAME"temp_consensus.cons -uc "$EXPTNAME"temp_consensus.uc --usersort
	grep '^C' "$EXPTNAME"temp_consensus.uc | awk 'BEGIN {max = 0} {if ($3>max) cluster=$2; if($3>max) max=$3} END { print ">Cluster" cluster "$"}' > "$EXPTNAME"temp_cons_cluster.txt
	maxreads=$(grep '^C' "$EXPTNAME"temp_consensus.uc | awk 'BEGIN {max = 0} {if ($3>max) cluster=$2; if($3>max) max=$3} END {print max}')
	fasta_formatter -i "$EXPTNAME"temp_consensus.cons -o "$EXPTNAME"temp_consensus_oneline.cons -w 0
	echo $line | awk -v maxreads=$maxreads '{print ">" $3 $4 "_" maxreads "clusteredreads"} ' >> "$EXPTNAME"paired_consensus_seqs.txt
	grep -f "$EXPTNAME"temp_cons_cluster.txt -A 1 -m 1 "$EXPTNAME"temp_consensus_oneline.cons >> "$EXPTNAME"paired_consensus_seqs.txt

	#echo "oneloop"
done < "$EXPTNAME"temppairs_CDR3seqs.txt

echo "$(date +%b-%d-%H:%M:%S)   Writing all CDR3 consensus seqs to paired_consensus_seqs.fasta ..."

grep -v Cluster "$EXPTNAME"paired_consensus_seqs.txt | grep -v '\--' > "$EXPTNAME"paired_consensus_seqs.fasta

echo "$(date +%b-%d-%H:%M:%S)   Job complete.  Pairs are located in "$EXPTNAME"paired_consensus_seqs.fasta"