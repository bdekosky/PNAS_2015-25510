This suite of scripts performs the paired VH:VL IgBLAST antibody sequence analysis.

****************

1)  Quality filter raw data to Q-score of 20 over 50% of the read (http://hannonlab.cshl.edu/fastx_toolkit/)

2)  Identify only those paired MiSeq R1/R2 pairs which pass quality filtering for both reads.  Place these into cognate R1 and R2 files.

3)  Use the Linux split command to split sequence libraries into parallel files of 50,000 sequences each to perform IgBLAST annotation in parallel:

	bash CDR3motif_search_part1_v2.0.sh READ1FILE_aa READ2FILE_aa
	bash CDR3motif_search_part1_v2.0.sh READ1FILE_ab READ2FILE_ab
	.
	.
	.
	bash CDR3motif_search_part1_v2.0.sh READ1FILE_** READ2FILE_**

4)  Concatenate the *igblast_isotype.txt file output from Step 3 into a single file (EXPT_PREFIX_igblast_isotype_all.txt) for the compilation/annotation script:

	bash CDR3motif_search_part2_v2.0.sh EXPT_PREFIX_ EXPT_PREFIX_igblast_isotype_all.txt
	
5)  Perform the clustering analysis on the *CDR3_nt_pairs_over1read.txt file output from Step 4 for quality filtering of paired VH:VL sequence data:

	bash CDR3motif_search_analysis_v2.0.sh EXPT_PREFIX_ EXPT_PREFIX_CDR3_nt_pairs_over1read.txt

5)  The output file EXPT_PREFIX_unique_pairs_over1read.tx contains clustered VH:VL sequences ready for further analysis.  EXPT_PREFIX_CDR3_nt_pairs_over1read.txt contains paired CDR-H3:CDR-L3 data prior to clustering analysis.