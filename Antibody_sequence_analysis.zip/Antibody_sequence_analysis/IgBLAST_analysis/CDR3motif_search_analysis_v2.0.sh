#!/bin/bash
#
#Process CDR3 motif nt results file _CDR3_nt_pairs.txt via clustering
#Input:  CDR3pairing_analysis_v1.0.sh Expt_prefix EXPT_CDR3_nt_pairs.txt

EXPTNAME=$1
RAW_CDR3ntpairs=$2

echo "$(date +%b-%d-%H:%M:%S)   Preparing files..."

#Generating a list of HC sequences observed in pairs >=2 times
awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {if ($1>1) print ">" exptname "_completepairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$RAW_CDR3ntpairs" > "$EXPTNAME"heavynt_junctions_over1read.fasta

#echo "$(date +%b-%d-%H:%M:%S)   96% clustering the CDR-3 junction sequences..."
usearch -cluster "$EXPTNAME"heavynt_junctions_over1read.fasta -w 4 --maxrejects 0 -usersort --iddef 2 --nofastalign -id 0.96 -minlen 11 -uc "$EXPTNAME"results.uc -seedsout "$EXPTNAME"seeds.uc

#generate list of clonotypes & frequencies based on unique sequencees
awk '/>/{getline;print}' "$EXPTNAME"seeds.uc > "$EXPTNAME"uniqueHCntseqs_over1read.txt

while read line
do      
    grep -m 1 "$line" "$RAW_CDR3ntpairs" >> "$EXPTNAME"unique_pairs_over1read.txt
done < "$EXPTNAME"uniqueHCntseqs_over1read.txt

#Filter unique_pairs for seqs with >=2 reads
#awk '{if($1>1)print}' "$EXPTNAME"unique_pairs.txt | sort -n -r > "$EXPTNAME"unique_pairs_over1read.txt

#Output FASTA files with CDR-H3 for unique pairs and top heavy/light filtered pairs
awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {print ">" exptname "uniquepairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"unique_pairs_over1read.txt > "$EXPTNAME"CDR-H3_unique_seqs_over1read.fasta

echo "$(date +%b-%d-%H:%M:%S)   Job complete."

echo 'Total number of paired reads:'
awk '{sum+=$1}; END {print sum}' "$RAW_CDR3ntpairs"

echo 'Recovered unique pairs:'
#wc -l "$EXPTNAME"unique_pairs.txt
wc -l "$EXPTNAME"unique_pairs_over1read.txt
