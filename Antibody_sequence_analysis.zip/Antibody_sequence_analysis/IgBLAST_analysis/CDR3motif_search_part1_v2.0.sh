#!/bin/bash
#
#Process two FASTA files R1 and R2 for VH:VL pairs using CDR3 motif
#Input:   CDR3motif_search.sh R1_fasta_file R2_fasta_file

R1fasta=$1
R2fasta=$2

date; perl vpairhumanalysis-igblast-isotype_BDmod.pl "$R1fasta" "$R2fasta" human_barcodes.txt; date

