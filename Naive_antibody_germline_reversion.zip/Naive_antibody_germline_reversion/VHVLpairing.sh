#!/bin/bash

#Process workflow through VH-VL pairs from 3_ IMGT nucleotide files
#Outputs several files of VH-VL pairing information
#completeVHVLpairs: contains all sequences with nt junction, V(D)J usage info, CDR3 length
#unique_pairs: contains one entry for each unique pair given by 97% clusterin of CDR3 junction
#unique_heatmapdata:  contains a list of VH-VL pairings ready for import into Excel

EXPTNAME=$1

FILE1=$2
FILE2=$3
FILE3=$4
FILE4=$5
FILE5=$6

rm "$EXPTNAME"unique_pairs.txt

echo "$(date +%b-%d-%H:%M:%S)   Preparing files..."
cat $FILE1 $FILE2 $FILE3 $FILE4 $FILE5 | sed 's/ 1:/_1:/g' | sed 's/ 2:/_2:/g' > pairings_temp_ntdatafile.txt
#print heavy chains in tab-sep file SeqID JunctionNT V-GeneAllele J-GeneAllele D-GeneAllele  CDRH3-length
grep -v '^S' pairings_temp_ntdatafile.txt | awk 'BEGIN {FS="\t"}; {split($4,Vgene," "); split($5,Jgene," "); split($6,Dgene," "); if($3=="productive") if(length($7)>1) print $2 "\t" $16 "\t" Vgene[2] "\t" Jgene[2] "\t" Dgene[2] "\t" length($15)}' | sort -t $'\t' > "$EXPTNAME"IMGT_ntheavys.csv
#same with lights SeqID JunctionNT V-GeneAllele J-GeneAllele CDRL3-length
grep -v '^S' pairings_temp_ntdatafile.txt | awk 'BEGIN {FS="\t"}; {split($4,Vgene," "); split($5,Jgene," "); if($3=="productive") if(length($8)>1) print $2 "\t" $16 "\t" Vgene[2] "\t" Jgene[2] "\t" length($15)}' | awk 'BEGIN {FS="_"}; {if (substr($2,1,1)==1) print $1 "_" "2" substr($2,2); else if (substr($2,1,1)==2) print $1 "_" "1" substr($2,2)}' | sort -t $'\t' > "$EXPTNAME"IMGT_ntlights_readrev.csv

#join for VH-VL junction pairings file
join -t $'\t' -j 1 -o 1.2 2.2 "$EXPTNAME"IMGT_ntheavys.csv "$EXPTNAME"IMGT_ntlights_readrev.csv | sort | uniq -c | sort -n -r | awk '{if ($2!=$3) print $0}' | sed "s/^ *//" | sed 's/ /\t/g' > "$EXPTNAME"VHVLpairs.txt
#join for complete info pairings file HjunctionNT LjunctionNT HV-gene HJ-gene HD-gene HCDR3-length LV-gene LJ-gene LCDR3-length
join -t $'\t' -j 1 -o 1.2 2.2 1.3 1.4 1.5 1.6 2.3 2.4 2.5 "$EXPTNAME"IMGT_ntheavys.csv "$EXPTNAME"IMGT_ntlights_readrev.csv | sort | uniq -c | sort -n -r | awk '{if ($2!=$3) print $0}' | sed "s/^ *//" | sed 's/ /\t/g' > "$EXPTNAME"completeVHVLpairs.txt

#generate unique clonotype data list  NbLinesinVHVLpairsList VL-gene JL-gene CDL3-length VH-gene JH-gene CDH3-length
#awk 'BEGIN {FS="\t"}; {print $7 "\t" $8 "\t" $9 "\t" $3 "\t" $4 "\t" $6 }' "$EXPTNAME"completeVHVLpairs.txt | sort | uniq -c | sort -n -r 

#echo "$(date +%b-%d-%H:%M:%S)   Creating a list of unique paired nt junctions read more than 0 times..."
awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {if ($1>0) print ">" exptname "_completepairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"VHVLpairs.txt > "$EXPTNAME"heavynt_junctions.fasta

#echo "$(date +%b-%d-%H:%M:%S)   96% clustering the CDR-3 junction sequences..."
usearch -cluster "$EXPTNAME"heavynt_junctions.fasta -w 4 --maxrejects 0 -usersort --iddef 2 --nofastalign -id 0.96 -minlen 11 -uc results.uc -seedsout seeds.uc

#generate list of clonotypes & frequencies based on unique sequencees
awk '/>/{getline;print}' seeds.uc > "$EXPTNAME"uniqueHCntseqs.txt

while read line
do      
    grep -m 1 "$line" "$EXPTNAME"completeVHVLpairs.txt >> "$EXPTNAME"unique_pairs.txt
done < "$EXPTNAME"uniqueHCntseqs.txt

#generate unique HC seq VH-VL data list  VH-gene JH-gene (DH-gene) CDH3-length VL-gene JL-gene CDL3-length 
awk 'BEGIN {FS="\t"}; {print $4 "\t" $5 "\t" $6 "\t" $7 "\t" $8 "\t" $9 "\t" $10 }' "$EXPTNAME"unique_pairs.txt > "$EXPTNAME"unique_Dgene_VHVLdata.txt
awk 'BEGIN {FS="\t"}; {print $4 "\t" $5 "\t" $7 "\t" $8 "\t" $9 "\t" $10 }' "$EXPTNAME"unique_pairs.txt > "$EXPTNAME"unique_VHVLdata.txt

#Perform topheavy/toplight filters
#awk '{print $2}' "$EXPTNAME"completeVHVLpairs.txt | sort | uniq > tHL-matching-script_temp_CDR-H3.txt
#awk '{print $3}' "$EXPTNAME"completeVHVLpairs.txt | sort | uniq > tHL-matching-script_temp_CDR-L3.txt
#rm topheavys.txt
#rm toplights.txt
#echo "$(date +%b-%d-%H:%M:%S)   Beginning top heavy/light pairing loops..."

#while read line
#do     
#    grep -m 1 "$line" "$EXPTNAME"completeVHVLpairs.txt >> toplights.txt
#done < tHL-matching-script_temp_CDR-L3.txt

#while read line
#do     
#    grep -m 1 "$line" "$EXPTNAME"completeVHVLpairs.txt >> topheavys.txt
#done < tHL-matching-script_temp_CDR-H3.txt

#echo "$(date +%b-%d-%H:%M:%S)   Top heavy/light pairing loops complete..."
#sort topheavys.txt > topheavys_sorted.txt; sort toplights.txt > toplights_sorted.txt
#join -t 'IGHV' -j 1 -o 1.1 1.2 1.3 1.4 1.5 1.6 topheavys_sorted.txt toplights_sorted.txt | sort | uniq | sort -n -r > "$EXPTNAME"topHLpairs.txt

#Filter topHLpairs for seqs with >=2 reads
#awk '{if($1>1)print}' "$EXPTNAME"topHLpairs.txt > "$EXPTNAME"topHLpairs_over1read.txt

#Filter unique_pairs for seqs with >=2 reads
awk '{if($1>1)print}' "$EXPTNAME"unique_pairs.txt | sort -n -r > "$EXPTNAME"unique_pairs_over1read.txt

#Generate noallele topHLpairs files for Excel pivot table heat maps
#awk '{gsub("\*[0-9]*\t", "\t"); print}' "$EXPTNAME"topHLpairs_over1read.txt > "$EXPTNAME"topHLpairs_over1read_noalleles.txt

#Generate noallele unique_pairs files for Excel pivot table heat maps
awk '{gsub("\*[0-9]*\t", "\t"); print}' "$EXPTNAME"unique_pairs_over1read.txt > "$EXPTNAME"unique_pairs_over1read_noalleles.txt

#Output FASTA files with CDR-H3 for unique pairs and top heavy/light filtered pairs
awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {print ">" exptname "uniquepairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"unique_pairs.txt > "$EXPTNAME"CDR-H3_unique_seqs.fasta
awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {print ">" exptname "uniquepairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"unique_pairs_over1read.txt > "$EXPTNAME"CDR-H3_unique_seqs_over1read.fasta
#awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {print ">" exptname "topHLpairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"topHLpairs.txt > "$EXPTNAME"CDR-H3_topHL_seqs.fasta
#awk -v exptname="$EXPTNAME" 'BEGIN {i=1}; {if($1>1) print ">" exptname "topHLpairs_CDR-H3_Rank_" i "_\n" $2; i=i+1}' "$EXPTNAME"topHLpairs.txt > "$EXPTNAME"CDR-H3_topHL_seqs_over1read.fasta

echo "$(date +%b-%d-%H:%M:%S)   Job complete."

echo 'head ' "$EXPTNAME"'VHVLpairs.txt'
head "$EXPTNAME"VHVLpairs.txt
echo 'Total number of paired reads:'
awk '{sum+=$1}; END {print sum}' "$EXPTNAME"completeVHVLpairs.txt
echo "$EXPTNAME"'completeVHVLpairs.txt'

rm pairings_temp_ntdatafile.txt
rm "$EXPTNAME"IMGT_ntheavys.csv
rm "$EXPTNAME"IMGT_ntlights_readrev.csv

#echo 'head ' "$EXPTNAME"'topHLpairs.txt'
#head "$EXPTNAME"topHLpairs.txt
#echo "$EXPTNAME" 'topHLpairs.txt'
wc -l "$EXPTNAME"unique_pairs.txt
wc -l "$EXPTNAME"unique_pairs_over1read.txt
#wc -l "$EXPTNAME"topHLpairs.txt
#wc -l "$EXPTNAME"topHLpairs_over1read.txt


