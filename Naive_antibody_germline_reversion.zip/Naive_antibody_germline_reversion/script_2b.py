#Purpose: script to revert raw reads from paired data into full length germline nucleotide sequences 
#Usage: python script_2b.py imgt_nt imgt_gap_nt imgt_mutation germ_lib outputfile_prefix



import sys
import collections
from collections import defaultdict

#usage: python script imgt_nt imgt_gap_nt imgt_mutation germ_lib outputfile_prefix

########################################################
########################################################
# This banks everything in the nucleotide file

inputfile=open(sys.argv[1])

data=inputfile.readlines()

inputfile.close()

banked_indices_dict_dict=defaultdict(list)

banked_indices_dict={}

count=len(data)

original_line_number_minus_title=len(data)

stored_indices=[]
k=0
while k < 114:
	stored_indices.append(k)
	k +=1
	
i=1
while i < (count):
        rowoflines=data[i]
        split_by_tab_line=rowoflines.split("\t")
	if len(split_by_tab_line)>4: #and split_by_tab_line[13] != '': #gets rid of any sequence without a CDR3 #this is actually basically just anything with NO RESULTS
		j=1
		while j < 114:
			if stored_indices[j] < len(split_by_tab_line):
				banked_indices_dict_dict[split_by_tab_line[0]].append(split_by_tab_line[stored_indices[j]])
			else :
				banked_indices_dict_dict[split_by_tab_line[0]].append("")
			j=j+1
	i=i+1


num_with_small_CDR3=0
unproductive_count_before=0
unproductive_count_after=0
other_count=0
noJorCDR3=0

for key in banked_indices_dict_dict: ###########################################################this section here filters out the sequences that do not have CDR3's or J genes!!!!! 
	value=banked_indices_dict_dict[key]
	if value[1]=="unproductive":
		unproductive_count_before+=1
	if value[13] !='': # and len(value[13]) >=4:
		if value[39] !='':
			if value[1] != "unproductive": ##########################################filter out anything that is unproductive
				banked_indices_dict[key]=banked_indices_dict_dict[key]
				other_count+=1
	if value[13]=='':
		noJorCDR3+=1
	elif value[39]=='':
		noJorCDR3+=1

print noJorCDR3
		
print "the below is what is being weirdly lost"

print "the below was NOT UNPRODUCTIVE and had a CDR3 and J"
print other_count
count_before=0
for key in banked_indices_dict_dict:
	count_before +=1
count_after=0
for key in banked_indices_dict:
	count_after +=1

num_filt=count_before-count_after

print num_filt
print "The above had some results but had no CDR3 and/or J"

no_results_num=count-count_before

print count-count_before
print "The above was how many had no results at all"

print "Overall filtering anything without a CDR3, a J and no results"
print num_filt+(count-count_before)
	
#########################################################
#########################################################
# This banks everything in the gapped nucleotide file

inputfile=open(sys.argv[2])

data=inputfile.readlines()

inputfile.close()

banked_gap_dict=defaultdict(list)

count=len(data)

stored_indices=[]
k=0
while k < 18:
        stored_indices.append(k)
        k +=1


for key in banked_indices_dict:
	i=1
	while i < count:
		rowoflines=data[i]
		split_by_tab_line=rowoflines.split("\t")
		if split_by_tab_line[0]==key:
			j=1
			while j < 18:
				if stored_indices[j] < len(split_by_tab_line):
					banked_gap_dict[key].append(split_by_tab_line[stored_indices[j]])
				else:
					banked_gap_dict[key].append("")
				j +=1
		i +=1

#print banked_gap_dict #should only have sequences with CDR3's, meaning good reads??




#########################################################
#########################################################
# This banks everything in the mutation file
inputfile=open(sys.argv[3])

data=inputfile.readlines()

inputfile.close()

banked_mut_dict=defaultdict(list)

count=len(data)

stored_indices=[]
k=0
while k < 11:
        stored_indices.append(k)
        k +=1


for key in banked_indices_dict:
        i=1
        while i < count:
                rowoflines=data[i]
                split_by_tab_line=rowoflines.split("\t")
                if split_by_tab_line[0]==key:
                        j=1
                        while j < 11:
                                if stored_indices[j] < len(split_by_tab_line):
                                        banked_mut_dict[key].append(split_by_tab_line[stored_indices[j]])
                                else:
                                        banked_mut_dict[key].append("")
                                j +=1
                i +=1

#print banked_mut_dict #should only have sequences with CDR3's, meaning good reads??

#############################################################
#############################################################
#this banks the germline libraries

def bank_germline_dictionary(x):

        inputfile=open(sys.argv[x])

        data=inputfile.readlines()

        inputfile.close()

        sys.argv[x]={}

	count=0
       	for line in data:
		count+=1
	i=0
	while i<count:
		key=data[i].rstrip()
		sequence=data[i+1].rstrip()
		sys.argv[x][key]=sequence	
		i+=2
     

bank_germline_dictionary(4) #JH ##################################%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%This is now for banking all of the libraries at once 

#############################################################
#############################################################
# Try to make the mutation file more useful by parsing it


mutation_split_by_bar={}

for key in banked_mut_dict:
        value=banked_mut_dict[key][9] #this is only for the CDR3 mutations
        if value != None: #None represents a whitespace in python, or no value in this case, other things can represent ws too
                split_by_bar=value.split("|")
                mutation_split_by_bar[key]=split_by_bar

mutation_single_split_by_character={}

#list to keep track of sequences without mutations
track_mutations=[]

for key in mutation_split_by_bar:
        value=mutation_split_by_bar[key]
        if value == ['']:
                track_mutations.append(key)

for item in track_mutations: #for loop deletes any sequences in the dictionary that have no mutations
        del mutation_split_by_bar[item]

mutation_del_nonsilent_dict=defaultdict(list)

for key in mutation_split_by_bar: #this for loop deletes any empty spaces in the list of mutations, sometimes at the end
        value=mutation_split_by_bar[key]
        for item in value[:]: #this is looking at a copy of your list, allowing you to remove things from the Woriginal list, without changing the length of the list while iterating
                if item == '' :
                        value.remove(item)
                else:
                        split_item=list(item)
                        mutation_del_nonsilent_dict[key].append(split_item)

#########################################################################
#########################################################################
# All of the above was borrowed from the first code
#Everything below is being created to collapse the integers into one number so I will have in my dicitonary "base, num, >, base"

#try to delete any of the nonsilent mutation information before you try to concatenate the nucleotide position number

minus_nonsilent_dict=defaultdict(list)

for key in mutation_del_nonsilent_dict:
	#use the copy trick
	value=mutation_del_nonsilent_dict[key]
	for item in value[:]:
		k=0
		item_specific_list=[]
		while k < len(item) and item[k] != ',':
			item_specific_list.append(item[k])
			k +=1
		minus_nonsilent_dict[key].append(item_specific_list)


#concatenating the nucleotide position back from its characters and leaving everything else as characters
mutation_number_concat=defaultdict(list)

for key in minus_nonsilent_dict:
	value=minus_nonsilent_dict[key]
	for item in value:
		length_item=len(item)
		temp=""
		i=0
		while i < length_item:

			if item[i] == 'a' or item[i]== 'g' or item[i]== 't' or item[i]== 'c':
				mutation_number_concat[key].append(item[i])
				
			if item[i] == '0'or item[i] == '1' or item[i]=='2' or item[i]=='3' or item[i]=='4' or item[i]=='5' or item[i]=='6' or item[i]=='7' or item[i]=='8' or item[i]=='9':
				temp=temp+str(item[i])
				if (i+1) < length_item and item[i+1] == '>':
					mutation_number_concat[key].append(temp)
			i +=1

#print mutation_number_concat
			
#mutation_number_concat now contains all of the mutations in the format "base, nucleotide, base etc etc"

#loop through the mutation positions and see if they are within your required ranges of V, D and J

final_stuff=defaultdict(list)

for key in mutation_number_concat:
	value=banked_gap_dict[key]
	VDJ_gap=value[5]
	VJ_gap=value[6]
	V_gap=value[7]
	J_gap=value[15]
	CDR3=value[13]
	CDR3_explode=list(CDR3)
	CDR3_list_positions=[]
	if VDJ_gap !='':
		V_start_index=VDJ_gap.find(V_gap)
		V_length=len(V_gap)
		V_end=V_start_index+V_length-1 #must be less than this number #should give me the number of the nucleotide positon that i want to compare with the mutaiton position #just add 1 more if want to take into account the 3 nt instead of 2
		J_start_index=VDJ_gap.find(J_gap)
		J_start=J_start_index+2 #need to add one so that i can compare this number with the mutation position ###must be greater than this number
		CDR3_start=VDJ_gap.find(CDR3)+1
		CDR3_length=len(CDR3)
		CDR3_end=CDR3_start+CDR3_length-1
		k=CDR3_start
		while k <= CDR3_end: #populate a list to represent these indices which you can compare to the mutation position and later you will use the indexes of these to convert the nt in the CDR3 sequence
			CDR3_list_positions.append(k)
			k +=1

		mutation_data=mutation_number_concat[key]

		count=0
		for item in mutation_data:
			if item != 'a' and item != 'g' and item != 'c' and item != 't':
#				print char
				if int(item) < V_end: # or int(item) > J_start:
					j=0
					while j < len(CDR3_list_positions):
						if int(item)==CDR3_list_positions[j]:
							before_mut=CDR3_explode[j]
							CDR3_explode.pop(j)
							CDR3_explode.insert(j, mutation_number_concat[key][count-1])
						j +=1
			count +=1

		final_stuff[key].append(CDR3_explode)
								
							
####do some more stuff here
	if VJ_gap !='':
		V_start_index=VJ_gap.find(V_gap)
                V_length=len(V_gap)
                V_end=V_start_index+V_length-1 #must be less than this number #should give me the number of the nucleotide positon that i want to compare with the mutaiton position #just add 1 more if want to take into accou$
                J_start_index=VJ_gap.find(J_gap)
                J_start=J_start_index+2 #need to add one so that i can compare this number with the mutation position ###must be greater than this number
                CDR3_start=VJ_gap.find(CDR3)+1
                CDR3_length=len(CDR3)
                CDR3_end=CDR3_start+CDR3_length-1
                k=CDR3_start
                while k <= CDR3_end: #populate a list to represent these indices which you can compare to the mutation position and later you will use the indexes of these to convert the nt in the CDR3 sequence
                        CDR3_list_positions.append(k)
                        k +=1

                mutation_data=mutation_number_concat[key]
		count=0
                for item in mutation_data:
                        if item != 'a' and item != 'g' and item != 'c' and item != 't':
                        	if int(item) < V_end: # or int(item) > J_start:

                                	j=0
                                	while j < len(CDR3_list_positions):
                                		if int(item)==CDR3_list_positions[j]:
                                                	before_mut=CDR3_explode[j] #should actually be called before_revert
                                                        CDR3_explode.pop(j)
                                                        CDR3_explode.insert(j, mutation_number_concat[key][count-1])
						j +=1
			count +=1

                final_stuff[key].append(CDR3_explode)

###########################################################
###########################################################
#need to go back in and add everything else that didn't have a mutation

for key in banked_indices_dict:
	if key in final_stuff.keys():
		nothing=1
	else:
		value=banked_gap_dict[key]
		CDR3=value[13]
		CDR3_explode=list(CDR3)
		final_stuff[key].append(CDR3_explode) 

###########################################################
########################################################### 
###########################################################
# Before concatenating and fixing the output, you must compare the length of J's trim off the difference
#then append on the first two and revert the rest to the germline

J_region_list={'4':'IGHJ',
                '5':'IGKJ',
                '6':'IGLJ'}
#the above are for searching in the keys


bank_new_J_piece=defaultdict(list)

pseudogene_J=0
could_not_align_num=0

def junction_stitch(database_num):
	global could_not_align_num 
        global pseudogene_J
	for key in banked_indices_dict:
                value=banked_gap_dict[key]

                
                list_characters=str(value[3]).split()
               	database_chain_code=list_characters[1]
                if database_chain_code in sys.argv[database_num].keys(): #should theoretically take $
                	top_database_seq=sys.argv[database_num][database_chain_code]
                        lc_top_db_seq=top_database_seq.lower()
			len_lc_top_db_seq=len(lc_top_db_seq)
			len_observed_j=len(str(value[15]))
			len_shorter=len_observed_j-2				
			if len_observed_j < len_lc_top_db_seq:
				
				i=len_observed_j-1
				while i >=5:
					alignment_word=str(value[15])[i-6:i]

					if lc_top_db_seq.find(alignment_word) != -1: # THIS SHOULD FILTER OUT ANYTHING THAT CAN'T ALIGN
						word_start_index=lc_top_db_seq.find(alignment_word)
							
						real_3_prime_diff=word_start_index-i+6
						germline_length_needed=len_lc_top_db_seq-real_3_prime_diff-2
						germline_short=lc_top_db_seq[(-germline_length_needed):]

						bank_new_J_piece[key].append(str(value[15])[:(-len_shorter)])
                                                bank_new_J_piece[key].append(germline_short)
						break
					i-=1
				if i>=3 and i<5: #reached the end and no alignment was possible, so that wasn't a very good call
#					print "nothing matched???"
					could_not_align_num +=1

                      	elif bank_new_J_piece.get(key) == None and len_observed_j >= len_lc_top_db_seq : 
				bank_new_J_piece[key].append(str(value[15])[:-len_shorter])
				germline_short_LHS=lc_top_db_seq[(-len_shorter):]
				bank_new_J_piece[key].append(germline_short_LHS)
		else:
			pseudogene_J +=1
			print "J pseudogene?"
			print database_chain_code


junction_stitch(4) #must be integer not a string


############################################################
############################################################
# strip off the J gene part of the part that you fixed

trimmed_off_J={}

CDR3_end_less_than_J_begin=0

for key in final_stuff:
	global CDR3_end_less_than_J_begin

	value=banked_indices_dict[key]
	CDR3_start=value[57]

	CDR3_end=value[58]
	J_start=value[109]

	CDR3=final_stuff[key][0]

	if CDR3_end >= J_start: ############################################################################################MAJOR ISSUE, FILTERS OUT ANY INCORRECTLY DEFINED CDR3 BY IMGT!
		amount_to_trim=int(CDR3_end)-int(J_start)+1
		trimmed_CDR3=CDR3[:-amount_to_trim]
		trimmed_off_J[key]=trimmed_CDR3
	else: #adding this piece so we keep the ones with the J gene called outside of the CDR3, because there is no need to trim the CDR3 in order to squish it on
		trimmed_off_J[key]=CDR3
		CDR3_end_less_than_J_begin+=1



concat_trim_concat_mutation=defaultdict(list) #********

for key in final_stuff:
	if key in trimmed_off_J:# and (CDR3_end == J_start): #########################################################ANOTHER MAJOR PART OF FILTERING THIS STUFF OUT WITH INCORRECTLY LABELLED CDR3s
		concat_trim_concat_mutation[key].append(trimmed_off_J[key])
		concat_trim_concat_mutation[key].append(bank_new_J_piece[key])
		

everything_concatenated={}

		
#NOW CONCAT THEM ALL
for key in concat_trim_concat_mutation:
	concat_one="".join(concat_trim_concat_mutation[key][0])
	i=0
	concat=""
	while i < len(concat_trim_concat_mutation[key][1]):
		concat=concat+concat_trim_concat_mutation[key][1][i]
		i +=1
	concat_final=concat_one+concat
	everything_concatenated[key]=concat_final





#concatenate everything dictionary!!!!!!!!!!!!!!!!
everything_finished={}
		
for key in final_stuff:
	concat_CDR3="".join(final_stuff[key][0]) 
	everything_finished[key]=concat_CDR3


#########################################################################################This last section takes of the situation where the CDR3 end and the J start are the same thing but you were adding add 2nt, so you needed to take off one, cuz you now had too many, they probably aren't very good reads

trying_something_dict={}

for key in everything_concatenated:
	value=banked_indices_dict[key]
	CDR3_end=value[58]
	J_start=value[109]
	if CDR3_end==J_start:
		trying_something_dict[key]=everything_concatenated[key][:-1]
	else:
		trying_something_dict[key]=everything_concatenated[key]

			
######################################################################Try to do Brandon's output
###Make a file of CDR3s that actually have had error corrections
###################################################################################################################CAVEAT, this section makes no sense unless you are just dealing with CDR3s because
# you are comparing to the original CDR3 so your CDR3+J will always be different, that's why this file contains everything
trying_something_else_dict={}

for key in everything_concatenated:
        value=banked_indices_dict[key]
        CDR3_end=value[58]
        J_start=value[109]
        if CDR3_end==J_start:
                trying_something_else_dict[key]=everything_concatenated[key][:-1]
        else:
                trying_something_else_dict[key]=everything_concatenated[key]

final_dict_keys=[]

for key in trying_something_dict:
        final_dict_keys.append(int(key))
        sorted_final_dict_keys=sorted(final_dict_keys)
count=0
total_count=0
for item in sorted_final_dict_keys:
	total_count +=1
	if banked_indices_dict[str(item)][13] != trying_something_else_dict[str(item)]:
		count +=1



###############################################################################
###############################################################################


mutation_split_by_bar={}

for key in banked_mut_dict:
        value=banked_mut_dict[key][3] #this is only for the CDR3 mutations
        if value != None: #None represents a whitespace in python, or no value in this case, other things can represent ws too
                split_by_bar=value.split("|")
                mutation_split_by_bar[key]=split_by_bar

mutation_single_split_by_character={}

#list to keep track of sequences without mutations
track_mutations=[]

for key in mutation_split_by_bar:
        value=mutation_split_by_bar[key]
        if value == ['']:
                track_mutations.append(key)

#print track_mutations

for item in track_mutations: #for loop deletes any sequences in the dictionary that have no mutations
        del mutation_split_by_bar[item]


mutation_del_nonsilent_dict_V=defaultdict(list)

for key in mutation_split_by_bar: #this for loop deletes any empty spaces in the list of mutations, sometimes at the end
        value=mutation_split_by_bar[key]
        for item in value[:]: #this is looking at a copy of your list, allowing you to remove things from the original list, without changing the length of the list while iterating
                if item == '' :
                        value.remove(item)
                else:
                        split_item=list(item)
                        mutation_del_nonsilent_dict_V[key].append(split_item)

#########################################################################
#########################################################################
# All of the above was borrowed from the first code
#Everything below is being created to collapse the integers into one number so I will have in my dicitonary "base, num, >, base"

#try to delete any of the nonsilent mutation information before you try to concatenate the nucleotide position number

minus_nonsilent_dict_V=defaultdict(list)

for key in mutation_del_nonsilent_dict_V:
	#use the copy trick
	value=mutation_del_nonsilent_dict_V[key]
	for item in value[:]:
		k=0
		item_specific_list=[]
		while k < len(item) and item[k] != ',':
			item_specific_list.append(item[k])
			k +=1
		minus_nonsilent_dict_V[key].append(item_specific_list)
		


#concatenating the nucleotide position back from its characters and leaving everything else as characters
mutation_number_concat_V=defaultdict(list)

for key in minus_nonsilent_dict_V:
	value=minus_nonsilent_dict_V[key]
	for item in value:
		length_item=len(item)
		temp=""
		i=0
		while i < length_item:
			if item[i] == 'a' or item[i]== 'g' or item[i]== 't' or item[i]== 'c':
				mutation_number_concat_V[key].append(item[i])
				
			if item[i] == '0'or item[i] == '1' or item[i]=='2' or item[i]=='3' or item[i]=='4' or item[i]=='5' or item[i]=='6' or item[i]=='7' or item[i]=='8' or item[i]=='9':
				#check to see if it is an integer
				temp=temp+str(item[i])
				if (i+1) < length_item and item[i+1] == '>':
					mutation_number_concat_V[key].append(temp)
			i +=1

			
#mutation_number_concat now contains all of the mutations in the format "base, nucleotide, base etc etc"

#loop through the mutation positions and see if they are within your required ranges of V, D and J

final_stuff_V=defaultdict(list)

for key in mutation_number_concat_V:
	value=banked_gap_dict[key]
	VDJ_gap=value[5]
	VJ_gap=value[6]
	V_gap=value[7]
	V_explode=list(V_gap)
	V_list_positions=[]
	if VDJ_gap !='':
		V_start_index=VDJ_gap.find(V_gap)
		V_length=len(V_gap)
		V_end=V_start_index+V_length-1 #must be less than this number #should give me the number of the nucleotide positon that i want to compare with the mutaiton position #just add 1 more if want to take into account the 3 nt instead of 2
		k=V_start_index+1
		while k <= V_end: #populate a list to represent these indices which you can compare to the mutation position and later you will use the indexes of these to convert the nt in the CDR3 sequence
			V_list_positions.append(k)
			k +=1

		mutation_data=mutation_number_concat_V[key]

		count=0
		for item in mutation_data:
			if item != 'a' and item != 'g' and item != 'c' and item != 't':
				if int(item) < V_end: # or int(item) > J_start:
					j=0
					while j < len(V_list_positions):
						if int(item)==V_list_positions[j]:
							before_mut=V_explode[j]
							V_explode.pop(j)
							V_explode.insert(j, mutation_number_concat_V[key][count-1])
						j +=1
			count +=1

		final_stuff_V[key].append(V_explode)
								
							
####do some more stuff here
	if VJ_gap !='':
		V_start_index=VJ_gap.find(V_gap)
                V_length=len(V_gap)
                V_end=V_start_index+V_length-1 #must be less than this number #should give me the number of the nucleotide positon that i want to compare with the mutaiton position #just add 1 more if want to take into accou$
                k=V_start_index+1
                while k <= V_end: #populate a list to represent these indices which you can compare to the mutation position and later you will use the indexes of these to convert the nt in the CDR3 sequence
                        V_list_positions.append(k)
                        k +=1

                mutation_data=mutation_number_concat_V[key]
		count=0
                for item in mutation_data:
                        if item != 'a' and item != 'g' and item != 'c' and item != 't':
                        	if int(item) < V_end: # or int(item) > J_start:
                                	j=0
                                	while j < len(V_list_positions):
                                		if int(item)==V_list_positions[j]:
                                                	before_mut=V_explode[j] #should actually be called before_revert
                                                        V_explode.pop(j)
                                                        V_explode.insert(j, mutation_number_concat_V[key][count-1])
						j +=1
			count +=1

                final_stuff_V[key].append(V_explode)
	
#ok, so now, you should have all of the mutations fixed in the V region, now let's delete and concatenate this information into a sequence

final_stuff_V_concat={}

for key in final_stuff_V:
	value=final_stuff_V[key][0]
	sequence=""
	for item in value:
		if item !='.':
			sequence +=item
	final_stuff_V_concat[key]=sequence

for key in everything_concatenated:
	if final_stuff_V_concat.get(key) == None:
		VDJ=banked_indices_dict[key][5]
		VJ=banked_indices_dict[key][6]
		if VDJ !='':
			final_stuff_V_concat[key]=VDJ
		else:
			final_stuff_V_concat[key]=VJ

#at this point you should now have a dictionary with all of the mutations fixed in the V region





 	
#*************************************************************************************
#######################################################################################
#######################################################################################
#######################################################################################
# BANK THE PIECE OF THE CDR3 THAT IS THE V GENE THEN SEARCH FOR IT IN THE DATABASE
		
V_region_list={'7':'IGHV',
                '8':'IGKV',
                '9':'IGLV'}

#the above are for searching in the keys


outputfile=open("report_unaligned_V_identifiers_new_germline.txt","a")


germline_V_ready_to_stitch=defaultdict(list)

pseudogene_V=0
V_could_not_align=0
def variable_stitch(database_num):
	global pseudogene_V
	global V_could_not_align
        for key in everything_concatenated:
                value=banked_indices_dict[key]
		CDR3_start=int(value[57])
        	V_end=int(value[46])
        	length_CDR3_V=V_end-CDR3_start+1
        	CDR3_J=everything_concatenated[key]
        	length_CDR3_J=len(CDR3_J)
        	trim_off_RHS_to_extract=length_CDR3_J-length_CDR3_V
        	piece_of_V=CDR3_J[:-trim_off_RHS_to_extract]
		little_piece_of_germ_V=str(final_stuff_V_concat[key][-7:]) #since you are only using this when the V piece is too small just use the last 5bp of the corrected observed seq to search with and align
		combined_piece_of_V=little_piece_of_germ_V+piece_of_V

        	if len(piece_of_V) > 4: 
                	
                        list_characters=str(value[2]).split()
                        database_chain_code=list_characters[1]
                        if database_chain_code in sys.argv[database_num].keys(): #should theoretically take care of pseudogenes
                                top_database_seq=sys.argv[database_num][database_chain_code]
                                lc_top_db_seq=top_database_seq.lower()
				if lc_top_db_seq.find(piece_of_V) != -1:
					V_germline_end_index=lc_top_db_seq.find(piece_of_V)-1
					germline_V_string=lc_top_db_seq[0:(V_germline_end_index+1)]
					germline_V_ready_to_stitch[key].append(germline_V_string)
				else:
					V_could_not_align+=1
					outputfile.write("{0}\n".format(value[0]))	
			else:
				print "pseudogene?"
				print database_chain_code
				pseudogene_V +=1
                if len(piece_of_V) <= 4: 
			
		#	print "made it past the search"
                	list_characters=str(value[2]).split()
                        database_chain_code=list_characters[1]
                        if database_chain_code in sys.argv[database_num].keys(): #should theoretically take care of pseudogenes
                        	top_database_seq=sys.argv[database_num][database_chain_code]
                                lc_top_db_seq=top_database_seq.lower()
                                if lc_top_db_seq.find(little_piece_of_germ_V) != -1:
                                	V_germline_end_index=lc_top_db_seq.find(little_piece_of_germ_V)-1+(7-len(piece_of_V))
                                        germline_V_string=lc_top_db_seq[0:(V_germline_end_index+1)]
                                        germline_V_ready_to_stitch[key].append(germline_V_string)
				else:
					V_could_not_align+=1
					outputfile.write("{0}\n".format(value[0]))
			else:
				print "pseudogene?"
				print database_chain_code 
				pseudogene_V +=1
       	
#for key in V_region_list:
variable_stitch(4) #must be integer not a string
	
outputfile.close()
#now add on the CDR3+J

for key in germline_V_ready_to_stitch:
	value=everything_concatenated[key]
	germline_V_ready_to_stitch[key].append(value)
	

#now concatenate all the pieces

for key in germline_V_ready_to_stitch:
	value=germline_V_ready_to_stitch[key]
	new_value="".join(value)
	germline_V_ready_to_stitch[key]=new_value

#########################################################################

outputfile=open("{0}_Germline_Reverted_error_recorded_new_germline.fasta".format(sys.argv[5]), "w")

final_dict_keys=[]

for key in germline_V_ready_to_stitch:
        final_dict_keys.append(int(key))
        sorted_final_dict_keys=sorted(final_dict_keys)
count=0
count_mutation=0
for item in sorted_final_dict_keys:

       	if banked_indices_dict[str(item)][5] !='':
           	outputfile.write(">{0}{1} {2} [V:{3}] [J:{4}] [D:{5}]\n".format(item,"H",banked_indices_dict[str(item)][0], banked_indices_dict[str(item)][2], banked_indices_dict[str(item)][3],banked_indices_dict[str(item)][4]))
                outputfile.write("%s\n" % germline_V_ready_to_stitch[str(item)])
                count +=1
       	if banked_indices_dict[str(item)][6] !='':
                outputfile.write(">{0}{1} {2} [V:{3}] [J:{4}]\n".format(item,"L",banked_indices_dict[str(item)][0], banked_indices_dict[str(item)][2], banked_indices_dict[str(item)][3]))
                outputfile.write("%s\n" % germline_V_ready_to_stitch[str(item)])
		count+=1

        if germline_V_ready_to_stitch[str(item)].find(banked_indices_dict[str(item)][13]) == -1:
        	count_mutation +=1

outputfil=open("RECORD_ERRORS_MASTER_new_germline.txt","a")


outputfil.write("Total Number of Sequences Initially:\n")
outputfil.write("%s\n" %original_line_number_minus_title)
outputfil.write("Total Number of Sequences that are either Unknown or Productive and have a CDR3 and J gene:\n")
outputfil.write("%s\n" %other_count)
outputfil.write("Total Number of Sequences After Filtering is:\n") 
outputfil.write("%s\n" %count) 
outputfil.write("Total Number of Sequences With V Gene Mutations (for Naive, theoretical Sequencing Errors):\n") 
outputfil.write("%s\n" %count_mutation) 
outputfil.write("Number of Sequences Marked as Unproductive by IMGT and Filtered Out:\n")
outputfil.write("%s\n" %unproductive_count_before)
outputfil.write("Number of Sequences that could be Missing CDR3 and/or J Gene and were Filtered Out:\n") 
outputfil.write("%s\n" %noJorCDR3) 
outputfil.write("Number of Sequences With No Results At All That Were Filtered Out:\n") 
outputfil.write("%s\n" %no_results_num) 
outputfil.write("Number of Sequences with J Pseudogenes that were filtered out:\n") 
outputfil.write("%s\n" %pseudogene_J) 
outputfil.write("Number of Sequences with V Pseudogenes that were filtered out:\n") 
outputfil.write("%s\n" %pseudogene_V) 
outputfil.write("Number of Sequences where the J could not be aligned that were filtered out:\n") 
outputfil.write("%s\n" %could_not_align_num) 
outputfil.write("Number of Sequences where the CDR3 was less than 5bp and were filtered out:\n")
outputfil.write("%s\n" %num_with_small_CDR3)
outputfil.write("Number of Sequences where the V gene could not be aligned or other miscellaneous reason:\n")
alignment_issues=original_line_number_minus_title-count-unproductive_count_before-noJorCDR3-no_results_num-pseudogene_J-pseudogene_V-could_not_align_num-num_with_small_CDR3
outputfil.write("%s\n" %alignment_issues)
outputfil.write("Number of sequences with CDR3 ending earlier than J gene begins, bad CDR3 calls by IMGT, not necessarily filtered out though:\n")
outputfil.write("%s\n" %CDR3_end_less_than_J_begin)
outputfil.write("NUmber of sequences where V gene could not be aligned and were filtered out:\n")
outputfil.write("%s\n" %V_could_not_align)

outputfil.close()



outputfile.close()

