#Purpose: script for removing duplicates across two datasets (ex 501 from 483/484 donors) 
#Usage: python script_5.py first_set second_set



import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter

inputfile1=open("{0}".format(sys.argv[1]), "r")
data_0_1=inputfile1.readlines()
data_1=[]
for line in data_0_1:
	stripped_line=line.rstrip()
	data_1.append(stripped_line)
inputfile1.close()
#print data_1
inputfile2=open("{0}".format(sys.argv[2]), "r")
data_0_2=inputfile2.readlines()
data_2=[]
for line in data_0_2:
	stripped_line=line.rstrip()
	data_2.append(stripped_line)
inputfile2.close()
	
dict={}

count1=1
for item in data_1:
	count1+=1
#	print count1

print "NUMBER OF ORIGINAL 501"
print count1/4
	
count2=1
for item in data_2:
	count2+=1

print "NUMBER OF ORIGINAL 483 or 484"
print count2/4

duplicate_dict={}

h=0
i=0
while i <= (count1-3):
#	print data_1[0]
	heavy=data_1[i]
#	print heavy
	light=data_1[i+2]
	heavy_seq=data_1[i+1]
	light_seq=data_1[i+3]
	pair=str(heavy_seq)+" "+str(light_seq)
#	print pair
#	print i
	pair_name=str(heavy)+" "+str(light)#+"Z"
	if pair in dict.keys():
		h+=1
		pair_name=pair_name+" "+"483 Duplicate"
		duplicate_dict[pair_name]=pair
	else:
		dict[pair]=pair_name		
	i+=4

print "NUMBER OF REPEATS WITHIN 483 IN TERMS OF AMINO ACIDS"
print h

#duplicate_dict={}
print "got to second"
#print dict.keys()


count_duplicates=0
j=0
while j <= (count2-3):
	heavy=data_2[j]
	light=data_2[j+2]
	heavy_seq=data_2[j+1]
	light_seq=data_2[j+3]
	pair=str(heavy_seq)+" "+str(light_seq)
	#print pair
	pair_name=str(heavy)+" "+str(light)+"484"

	if pair in dict.keys():
		#print "hello!"
		value=dict[pair]
		#dict[pair]=value+"Z"
		pair_name=pair_name+" "+"Found in 484"
		duplicate_dict[pair_name]=pair
	#if pair in dict.keys():
	#	print "yes"
		del dict[pair]
		count_duplicates+=1
		#duplicate_dict[pair]=pair_name
	j+=4

#print duplicate_dict

print "NUMBER OF DUPLICATES IS:"
print count_duplicates

outputfile=open("501_483_translated_and_condensed.fasta", "w")

sorted_dict=defaultdict(list)

k=0
for key in dict:
	k+=1
	value=dict[key]
#	print value
	split_value=value.split(" >")
	heavy=split_value[0]
#	print heavy
	num_heavy=heavy.split(" ")[0]
	num_H=[]
	for char in num_heavy:
		if char.isdigit():
			num_H.append(char)
	num_H="".join(num_H)	
	light=split_value[1]
#	print light
	split_key=key.split(" ")
	heavy_seq=split_key[0]
	light_seq=split_key[1]
	sorted_dict[num_H].append(heavy) 
	sorted_dict[num_H].append(heavy_seq)
	sorted_dict[num_H].append(light)
	sorted_dict[num_H].append(light_seq)
#	print "is this the problem?"

print "NUMBER OF FINAL 483 after condensing"
print k

list=[]
for key in sorted_dict:
	list.append(int(key))

sorted_list=sorted(list)

#print sorted_list
for item in sorted_list:
	outputfile.write(sorted_dict[str(item)][0])
	outputfile.write("\n")
	outputfile.write(sorted_dict[str(item)][1])
	outputfile.write("\n")
	outputfile.write(">{0}".format(sorted_dict[str(item)][2]))
	outputfile.write("\n")
	outputfile.write(sorted_dict[str(item)][3])
	outputfile.write("\n")
outputfile.close()

outputfile2=open("501_483_translated_and_condensed_duplicates.fasta", "w")


for key in duplicate_dict:
	value=duplicate_dict[key]
#       print value
        split_value=value.split(" ")
        heavy_seq=split_value[0]
        #print heavy_seq
        light_seq=split_value[1]
        split_key=key.split(" >")
        heavy=split_key[0]
        light=split_key[1]
        outputfile2.write(heavy)
        outputfile2.write("\n")
        outputfile2.write(heavy_seq)
        outputfile2.write("\n")
        outputfile2.write(light)
        outputfile2.write("\n")
        outputfile2.write(light_seq)
        outputfile2.write("\n")

outputfile2.close()



	
	
		
		
