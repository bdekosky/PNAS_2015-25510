
#Purpose: slice the three IMGT data files into files of 1000 sequences each
#Usage: python script_1.py unique_name

import sys
import os
import subprocess

from os import path, access, R_OK
from subprocess import call


#in order to run this script, give the three names of the split files, also give a final file number


i=1
PATH_3="3_Nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
PATH_2="2_IMGT-gapped-nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
PATH_7="7_V-REGION-mutation-and-AA-change-table_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
try:
        while path.exists(PATH_3)==True and path.exists(PATH_2)==True and path.exists(PATH_7)==True:
     
		#print "here"
		list_1=[PATH_3, PATH_2, PATH_7]
		for item in list_1:
               		inputfile=open(item)

			data=inputfile.readlines()

			inputfile.close()
#			print "here"

			count=len(data)

			k=0
			j=1

			outputfile=open("{0}_1000seq_{1}.txt".format(item, j), "w")

			while k < count:
        			if k%1000==0 and k>=1000:
                			j+=1
                			outputfile.close()
                			outputfile=open("{0}_1000seq_{1}.txt".format(item, j), "w")
					print outputfile
        			outputfile.write(data[k])
        			k+=1
			outputfile.close()

		i+=1
                PATH_3="3_Nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)
                PATH_2="2_IMGT-gapped-nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)
                PATH_7="7_V-REGION-mutation-and-AA-change-table_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)
except:
        char=1


