#Purpose: script to check all full length antibody sequences that were modelled against the 98% cutoff curated VH:VL pairs. 
#Usage: python script_6.py 98%_paired_file modeled_sequence_fasta_file

#####import modules

import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter
from decimal import Decimal
################################################################
#####extract information from the paired file
paired_database=defaultdict(list)

inputfile=open(sys.argv[1])

num=0
for line in inputfile:
	num+=1
	strip_line=line.rstrip()
	split_line=strip_line.split("\t")
	read_count=split_line[0]
	CDRH3_AA=split_line[3]
	CDRL3_AA=split_line[4]
	paired_database[num].append(read_count)
	paired_database[num].append(CDRH3_AA)
	paired_database[num].append(CDRL3_AA)

inputfile.close()
#################################################################

########extract information from the modeled_sequence_fasta_file

modeled_database=defaultdict(list)

inputfile=open(sys.argv[2])

i=0
random_num=0
data=inputfile.readlines()

while i< (len(data)-4):
	random_num+=1
        heavy_name=data[i].rstrip()
        heavy_seq=data[i+1].rstrip()
        light_name=data[i+2].rstrip()
        light_seq=data[i+3].rstrip()

        modeled_database[random_num].append(heavy_name)
        modeled_database[random_num].append(heavy_seq)
        modeled_database[random_num].append(light_name)
        modeled_database[random_num].append(light_seq)

        i+=4
inputfile.close()

################################################################

#loop through the paired database for each modeled sequence and make sure the CDR3s match and are found there and if not, report it

for key in modeled_database:

	heavy_seq=str(modeled_database[key][1])
	light_seq=str(modeled_database[key][3])

	for key1 in paired_database:
		read_count=paired_database[key1][0]
		CDRH3_AA=str(paired_database[key1][1])
		CDRL3_AA=str(paired_database[key1][2])
		
		#print CDRH3_AA
		#print CDRL3_AA
		
		if heavy_seq.find(CDRH3_AA)!=-1 and light_seq.find(CDRL3_AA)!=-1:
			modeled_database[key].append("MATCH")
			modeled_database[key].append(read_count)
################################################################

#loop through the updated modeled database and identify those that had a match and write it to the outputfile 

outputfile=open("{0}_matching_sequences.fasta".format(sys.argv[2]), "w")

for key in modeled_database:
	if len(modeled_database[key])==6:
		read_count=modeled_database[key][5] 
		if read_count>50:
			heavy_name=modeled_database[key][0]
			heavy_seq=modeled_database[key][1]
			light_name=modeled_database[key][2]
			light_seq=modeled_database[key][3]
		
			#write to outputfile
			outputfile.write("{0}\n".format(heavy_name))
			outputfile.write("{0}\n".format(heavy_seq))
			outputfile.write("{0}\n".format(light_name))
			outputfile.write("{0}\n".format(light_seq))

outputfile.close()

################################################################

