
#Purpose: script that runs the reversion script for each of the 1000 sequence files (from all 3 IMGT outputs for each of those sequences)
#Usage: python script_2.py unique_name

import sys
import os
import subprocess

from os import path, access, R_OK
from subprocess import call


#in order to run this script, give the three names of the split files, also give a final file number


i=1
PATH_3="3_Nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
PATH_2="2_IMGT-gapped-nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
PATH_7="7_V-REGION-mutation-and-AA-change-table_{0}_{1}.fasta_011113.txt".format(sys.argv[1], i)
try:
	while path.exists(PATH_3)==True and path.exists(PATH_2)==True and path.exists(PATH_7)==True:
		j=1
		PATH_1000_3="{0}_1000seq_{1}.txt".format(PATH_3,j)
		PATH_1000_2="{0}_1000seq_{1}.txt".format(PATH_2,j)
		PATH_1000_7="{0}_1000seq_{1}.txt".format(PATH_7,j)

		while path.exists(PATH_1000_3)==True and path.exists(PATH_1000_2)==True and path.exists(PATH_1000_7)==True:
			call(["python", "script_2b.py", "{0}".format(PATH_1000_3), "{0}".format(PATH_1000_2), "{0}".format(PATH_1000_7), "germline_library.txt", "{0}".format(PATH_1000_3)])
			j+=1
			PATH_1000_3="{0}_1000seq_{1}.txt".format(PATH_3,j)
			PATH_1000_2="{0}_1000seq_{1}.txt".format(PATH_2,j)
			PATH_1000_7="{0}_1000seq_{1}.txt".format(PATH_7,j)			
		i+=1
		PATH_3="3_Nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)
		PATH_2="2_IMGT-gapped-nt-sequences_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)
		PATH_7="7_V-REGION-mutation-and-AA-change-table_{0}_{1}.fasta_011113.txt".format(sys.argv[1],i)	
except:
	hi="hello"
