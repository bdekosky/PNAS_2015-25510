#Purpose: collapse file onto unique reads  
#Usage: python script_3.py input_file_name

import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter

inputfile=open("{0}".format(sys.argv[1]), "r")
	
dict={}

for h, line in enumerate(inputfile):
#	print line
	seq=str((next(inputfile)).rstrip())
#	print seq
#	if str(line).find(">"):
#		print h
	name=str(line.rstrip())
	#	seq=inputfile[h+1]
	dict[seq]=name

outputfile=open("{0}_CONDENSED_FILE.txt".format(sys.argv[1]), "w")

for key in dict:
	outputfile.write(dict[key])
	outputfile.write("\n")
	outputfile.write(key)
	outputfile.write("\n")

print "made it here"


	
	
		
		
