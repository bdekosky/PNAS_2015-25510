#Purpose: maps reverted reads back to the ranked VHVL pairs  
#Usage: python script_4.py unique_pairs_over1read.txt condensed_germline_reverted_file

import sys
import collections
import operator
from collections import defaultdict
from operator import itemgetter

def reverse(string):
	letters=list(string)
	letters.reverse()
	return "".join(letters)

def complement(string):
	basecomplement={'A':'T','C':'G','G':'C','T':'A','N':'N'}
	letters=list(string)
	letters=[basecomplement[base] for base in letters]
	return "".join(letters)

def reversecomplement(string):
	string=reverse(string)
	string=complement(string)
	return string

def bank_data(x):
	inputfile=open(sys.argv[x])
#	data=inputfile.readlines()
#	inputfile.close()
	sys.argv[x]={}
#	temp_dict={}
#	temp_list=[]
#	count=0
	if x ==2:
		for h, line in enumerate(inputfile):
			print h
			strip_line=line.rstrip()
			seq=(next(inputfile)).rstrip()
			sys.argv[x][strip_line]=seq

	if x ==1:
		count=0
		for h, line in enumerate(inputfile):
			print h
			strip_line=line.rstrip()
			stripped_line=strip_line.replace("\t", " ")
			sys.argv[x][count]=stripped_line
#			while count < 1:
#				print count
#				print sys.argv[x][count]
			count+=1


bank_data(1)
bank_data(2)





final_dict=defaultdict(list)



#figure out why not working!!!!

#list1=["tgtgcgagagctaggggtcgcctttacccctactactttgactactgg", "tgtcagcagtataataactggcctgcgctcactttc","IGHV1-46*0","IGHJ4*02","IGHD3-10", "IGKV3-15*0", "IGKJ4*01"]

#CDRH3=list1[0]
#HV_gene=list1[2]
#HJ_gene=list1[3]
#HD_gene=list1[4]
#CDRL3=list1[1]
#LV_gene=list1[5]
#LJ_gene=list1[6]

#for key1 in sys.argv[2]:
#	V_search_space_gen=(key1.split("["))[1]
#        if V_search_space_gen.find("or") !=-1:
#        	V_search_space=(V_search_space_gen.split("or"))[0]
#        else:
#          	V_search_space=V_search_space_gen
#	print V_search_space
#        J_search_space_gen=(key1.split("["))[2]
#     	if J_search_space_gen.find("or") !=-1:
#              	J_search_space=(J_search_space_gen.split("or"))[0]
#        else:
#           	J_search_space=J_search_space_gen
#	print J_search_space
#       	if key1.find("IGHD") !=-1:
#               	D_search_space_gen=(key1.split("["))[3]
#		print D_search_space_gen
#               	if D_search_space_gen.find("or") !=-1:
#             		D_search_space=(D_search_space_gen.split("or"))[0]
#                else:
#                   	D_search_space=D_search_space_gen
#			print D_search_space
#    	value=sys.argv[2][key1]
#	print value
#      	if value.find(CDRH3) !=-1 and V_search_space.find(HV_gene) !=-1 and J_search_space.find(HJ_gene) !=-1 and HD_gene !=" " and D_search_space.find(HD_gene) !=-1 and len(final_dict[key1]) < 2:
#       		final_dict[key1].append(value)
#		print "found a heavy"
              	#final_dict[key1].append(CDRH3)
               	#final_dict[key1].append(HV_gene)
              	#final_dict[key1].append(HJ_gene)
              	#final_dict[key1].append(HD_gene)
#       	if value.find(CDRH3) !=-1 and V_search_space.find(HV_gene) !=-1 and J_search_space.find(HJ_gene) !=-1 and HD_gene ==" " and key1.find("IGHD")==-1 and len(final_dict[key1]) < 2:
#             	final_dict[key1].append(value)
               	#final_dict[key1].append(CDRH3)
              	#final_dict[key1].append(HV_gene)
#     	if value.find(CDRL3) !=-1 and V_search_space.find(LV_gene) !=-1 and J_search_space.find(LJ_gene) !=-1 and len(final_dict[key1]) < 2:
#             	final_dict[key1].append(value)
#		print "found a light"
              	#final_dict[key1].append(CDRL3)
             	#final_dict[key1].append(LV_gene)
            	#final_dict[key1].append(LJ_gene)
#	if len(final_dict)==1 and len(final_dict[key1])==2:
#		break

#print final_dict

keep_track_key_dict=defaultdict(list) #USETA JUST BE A REGULAR DICTIONARY

ordered_dict=defaultdict(list)



def match():
	j=0
	for key in sys.argv[1]: #this is the topHL file
#		string_it=str(sys.argv[1][key])
#		replace_tab=string_it.replace("\t", " ")
		split_string=(str(sys.argv[1][key])).split(" ")
#		print split_string
		freq=split_string[0]
		CDRH3=split_string[1]
		CDRL3=split_string[2]
#		print CDRL3
		#HV_gene=split_string[4] #must modify this because now we are using the fullalle script and theres more junk to look through, but the IGHV gene should always be the same
		k=0
		for item in split_string:
			if item.find("IGHV")!=-1 and k==0:
				k=1
				HV_gene=item


		k=0
		for item in split_string:
			if item.find("IGHJ")!=-1 and k==0:
				k=1
				HJ_gene=item
				
		#HJ_gene=split_string[4]
#		HJ_gene=split_string[4]
#		print HJ_gene
		k=0
		for item in split_string:
			if item.find("IGHD")!=-1 and k==0:
				k=1
				HD_gene=item
		if k==0:
			HD_gene=" "
		
		k=0
		for item in split_string:
			if (item.find("IGLV")!=-1 or item.find("IGKV")!=-1) and k==0:
				k=1
				LV_gene=item
		k=0
		for item in split_string:
			if (item.find("IGLJ")!=-1 or item.find("IGKJ")!=-1) and k==0:
				k=1
				LJ_gene=item
		#HD_gene=" "
		print split_string
		print freq
		print CDRH3
		print CDRL3
		print HV_gene
		print HJ_gene
		print HD_gene
#		print test_for_D
		#if test_for_D.find("IGHD") !=-1:
		#	HD_gene=test_for_D
		#	LV_gene=split_string[7]
		#	LJ_gene=split_string[8]
#			print LV_gene
#			print LJ_gene
		#else:
		#	LV_gene=split_string[7]
		#	LJ_gene=split_string[8]
		print LV_gene
		print LJ_gene

#		if key==35:
#			print LV_gene
#			print LJ_gene
#			print split_string
#			print CDRH3
#			print CDRL3
		for key1 in sys.argv[2]:
			key3=str(key1)
			if key3.find("[F]") !=-1:
				key3=key3.replace("[F]", "") #MODIFIED THIS IN VERSION 4.0 TO SIMPLIFY THE SEQUENCE IDENTIFIER
			#	print "replaced"
			if key3.find("F") !=-1:
				key3=key3.replace("F", "") #MODIFIED THIS IN VERSION 4.0 TO SIMPLIFY THE SEQUENCE IDENTIFIER 
			V_search_space_gen=(key3.split("["))[1] #sometimes there is a [F] with brackets wtf, or there is no "HomSap" and there is a "less than fewer than 6 nucleotides or some bs"
#			print V_search_space_gen
			if V_search_space_gen.find("or") !=-1:
				V_search_space=(V_search_space_gen.split("or"))[0]
			else:
				V_search_space=V_search_space_gen
			J_search_space_gen=(key3.split("["))[2]
#			print J_search_space_gen
			if J_search_space_gen.find("or") !=-1:
				J_search_space=(J_search_space_gen.split("or"))[0]
			else:
				J_search_space=J_search_space_gen
			if key3.find("IGHD") !=-1:
				D_search_space_gen=(key3.split("["))[3]
				if D_search_space_gen.find("or") !=-1:
					D_search_space=(D_search_space_gen.split("or"))[0]
				else:
					D_search_space=D_search_space_gen
			value=sys.argv[2][key1]

			if key1.find("F") !=-1:
				key1=key1.replace("F", "") # MODIFIED 
			if key1.find("[]]") !=-1:
				key1=key1.replace("[]]","]")
			if key1.find("Homsap") !=-1:
				key1=key1.replace("Homsap","")
			if key1.find("OR") !=-1:
				key1=key1.replace("OR", "or")
			if key1.find("[D:]") !=-1:
				key1=key1.replace("[D:]","[D: unassigned]")
			if key1.find("or]") !=-1:
				key1=key1.replace("or]", "]")
			if key1.find(", or") !=-1:
				key1=key1.replace(", or", "or")

			if value.find(CDRH3) !=-1 and V_search_space.find(HV_gene) !=-1 and J_search_space.find(HJ_gene) !=-1 and HD_gene !=" " and len(final_dict[key]) <2: # HD_gene !=" " and D_search_space.find(HD_gene) !=-1 and len(final_dict[key]) <2:
				if key in ordered_dict.keys():
					if str(ordered_dict[key]).find("H") == -1:
						ordered_dict[key].append("H")
						final_dict[key].append(value)
						split_key1=key1.split(" ")
		                                del split_key1[0]
						if str(split_key1).find("D:") ==-1:
							split_key1.append("[D: unassigned]")
                		                join_key1=" ".join(split_key1)
                                		keep_track_key_dict[key].append(join_key1)
						break
				if key not in ordered_dict.keys():
					ordered_dict[key].append("H")
					final_dict[key].append(value)
					split_key1=key1.split(" ")
	                                del split_key1[0]
					if str(split_key1).find("D:") ==-1:
						split_key1.append("[D: unassigned]")
        	                        join_key1=" ".join(split_key1)
                	                keep_track_key_dict[key].append(join_key1)
                        	#        print keep_track_key_dict

#				final_dict[key].append(CDRH3)
#				final_dict[key].append(HV_gene)
#				final_dict[key].append(HJ_gene)
#				final_dict[key].append(HD_gene)
			if value.find(CDRH3) !=-1 and V_search_space.find(HV_gene) !=-1 and J_search_space.find(HJ_gene) !=-1 and HD_gene ==" " and key1.find("IGHD")==-1 and len(final_dict[key]) < 2:
				if key in ordered_dict.keys():
					if str(ordered_dict[key]).find("H") ==-1:
						ordered_dict[key].append("H")
						final_dict[key].append(value)
						split_key1=key1.split(" ")
                                        	del split_key1[0]
						if str(split_key1).find("D:") ==-1:
							split_key1.append("[D: unassigned]")
                                        	join_key1=" ".join(split_key1)
                                        	keep_track_key_dict[key].append(join_key1)
						break					
				if key not in ordered_dict.keys():
					ordered_dict[key].append("H")
					final_dict[key].append(value)
					split_key1=key1.split(" ")
                                        del split_key1[0]
					if str(split_key1).find("D:") ==-1:
						split_key1.append("[D: unassigned]")
                                        join_key1=" ".join(split_key1)
                                        keep_track_key_dict[key].append(join_key1)
#				final_dict[key].append(CDRH3)
#				final_dict[key].append(HV_gene)
			if value.find(CDRL3) !=-1 and V_search_space.find(LV_gene) !=-1 and J_search_space.find(LJ_gene) !=-1 and len(final_dict[key]) < 2:
#				print "made it here"
				if key in ordered_dict.keys():
					if str(ordered_dict[key]).find("L") ==-1:
						ordered_dict[key].append("L")
						final_dict[key].append(value)
						split_key1=key1.split(" ")
#						print split_key1
						del split_key1[0]
#						print split_key1
						join_key1=" ".join(split_key1)
#						print join_key1
						keep_track_key_dict[key].append(join_key1)
#						keep_track_key_dict[key]=key1
#						final_dict[key].append(CDRL3)
#						final_dict[key].append(LV_gene)
#						final_dict[key].append(LJ_gene)
						break
				if key not in ordered_dict.keys():
					ordered_dict[key].append("L")
                                        final_dict[key].append(value)
                                        split_key1=key1.split(" ")
#                                       print split_key1
                                        del split_key1[0]
#                                       print split_ke
                                        join_key1=" ".join(split_key1)
#                                       print join_key1
                                        keep_track_key_dict[key].append(join_key1)





#			if key==76:
#				if value.find(CDRL3) !=-1 and key1.find(LV_gene) !=-1 and key1.find(LJ_gene) !=-1 and len(final_dict[key]) <2:
#					print key1
#					print LV_gene
#					print LJ_gene

#		print keep_track_key_dict
#		print final_dict
#		print ordered_dict
#		if key==76:
#			print V_search_space
#			print J_search_space
		print j
		j+=1	


match()


#print final_dict[15][1]

#print final_dict

outputfile=open("pre_translation_short.txt", "w")


#print keep_track_dict['541']

for key in final_dict:
	try:		
		if len(final_dict[key])<2:
			print key
			print"***************************************the above was only one**********************"
		if len(final_dict[key])==2:
			heavy_or_light=ordered_dict[key][0]
			if heavy_or_light == "H":
				outputfile.write(">{0}H {1}\n".format(key, keep_track_key_dict[key][0]))
				outputfile.write("{0}\n".format(final_dict[key][0]))
				outputfile.write(">{0}L {1}\n".format(key, keep_track_key_dict[key][1]))
				outputfile.write("{0}\n".format(final_dict[key][1]))
			elif heavy_or_light == "L":
				outputfile.write(">{0}H {1}\n".format(key, keep_track_key_dict[key][1]))
                		outputfile.write("{0}\n".format(final_dict[key][1]))
                		outputfile.write(">{0}L {1}\n".format(key, keep_track_key_dict[key][0]))
                		outputfile.write("{0}\n".format(final_dict[key][0]))
	except KeyError and IndexError:
		print "messed up in nucleotide:"
		print key
	
outputfile.close()

#make another file with the translations in it for the structural analysis

#codon_dict={'F':['ttt', 'ttc'], 'L':['tta', 'ttg','ctt','ctc','cta','ctg'], 'S':['tct', 'tcc', 'tca', 'tcg','agt','agc'],
#               'Y': ['tat','tac'], 'C':['tgt','tgc'], 'W':['tgg'],
#               'P':['cct','ccc','cca','ccg'], 'H':['cat','cac'], 'Q':['caa','cag'],'R':['cgt','cgc',
#               'cga','cgg','aga','agg'],'I':['att','atc','ata'], 'M':['atg'],'T':['act','acc','aca','acg'],
#               'N':['aat','aac'],'K':['aaa','aag'], 'V':['gtt','gtc','gta','gtg'], 'A':['gct','gcc',
#               'gca','gcg'], 'D':['gat','gac'],'E':['gaa','gag'], 'G':['ggt','ggc','gga','ggg']}


#heavy_amino_acid_dict=defaultdict(list)

#light_amino_acid_dict=defaultdict(list)

#for key in final_dict:
#	if len(final_dict[key])==2:
#	        try:
#			print key
#        	        heavy_or_light=ordered_dict[key][0]
 #               	if heavy_or_light == "H":
#                        	heavy=final_dict[key][0]
#                        	j=0
#                        	while (len(heavy)-j) > 2:
#                               		codon=heavy[j]+heavy[j+1]+heavy[j+2]
#                                	for key1 in codon_dict:
#                                        	for item in codon_dict[key1]:
#                                                	if codon == item:
#								print codon
#                                                        	heavy_amino_acid_dict[key].append(key1)
#					print j
#                                	j +=3
#                        	light=final_dict[key][1]
#                        	j=0
#                        	while (len(light)-j) > 2:
#                        	        codon=light[j]+light[j+1]+light[j+2]
#                                	for key1 in codon_dict:
#                                        	for item in codon_dict[key1]:
#                                                	if codon == item:
#                                                        	light_amino_acid_dict[key].append(key1)
#                                	j+=3
#                	if heavy_or_light =="L":
#                        	light=final_dict[key][0]
#                        	j=0
#                        	while (len(light)-j) > 2:
#                                	codon=light[j]+light[j+1]+light[j+2]
#                                	for key1 in codon_dict:
#                                        	for item in codon_dict[key1]:
#                                                	if codon == item:
#                                                        	light_amino_acid_dict[key].append(key1)
#                                	j+=3
#                        	heavy=final_dict[key][1]
#                        	j=0
#                        	while (len(heavy)-j) > 2:
#                                	codon=heavy[j]+heavy[j+1]+heavy[j+2]
#                                	for key1 in codon_dict:
#                                        	for item in codon_dict[key1]:
#                                                	if codon == item:
#                                                        	heavy_amino_acid_dict[key].append(key1)

#		except IndexError and KeyError:
#			print "problem key"
#			print key
			

#for key in heavy_amino_acid_dict:
#       value=heavy_amino_acid_dict[key]
#       new_value="".join(value)
#       heavy_amino_acid_dict[key]=new_value

#for key in light_amino_acid_dict:
#       value=light_amino_acid_dict[key]
#       new_value="".join(value)
#       light_amino_acid_dict[key]=new_value


#print out the translation

#outputfile=open("post_translation.txt","w")


#sort for printing
#final_dict_keys=[]

#for key in heavy_amino_acid_dict:
#        final_dict_keys.append(int(key))
#        sorted_final_dict_keys=sorted(final_dict_keys)


#print sorted_final_dict_keys

#print keep_track_key_dict

#print heavy_amino_acid_dict
#print light_amino_acid_dict

#for item in sorted_final_dict_keys:
#	try:
#		outputfile.write(">{0}H {1}\n".format(item, keep_track_key_dict[item]))
#		outputfile.write("{0}\n".format(heavy_amino_acid_dict[item]))
#		outputfile.write(">{0}L {1}\n".format(item, keep_track_key_dict[item]))
#		outputfile.write("{0}\n".format(light_amino_acid_dict[item]))
#	except IndexError and KeyError:
#		print "messed up in amino acid:"
#		print item

#outputfile.close()
